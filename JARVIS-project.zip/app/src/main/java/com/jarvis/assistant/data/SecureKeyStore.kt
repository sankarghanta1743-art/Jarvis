package com.jarvis.assistant.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Stores the Gemini API key encrypted with a key held in the Android Keystore.
 * The key is never logged and never written to plain files.
 */
class SecureKeyStore(context: Context) {

    private val prefs: SharedPreferences = run {
        val masterKey = MasterKey.Builder(context.applicationContext)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context.applicationContext,
            "jarvis_secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    fun getApiKey(): String? = prefs.getString(KEY_API, null)?.takeIf { it.isNotBlank() }

    fun hasApiKey(): Boolean = getApiKey() != null

    fun saveApiKey(key: String) {
        prefs.edit().putString(KEY_API, key.trim()).apply()
    }

    fun deleteApiKey() {
        prefs.edit().remove(KEY_API).apply()
    }

    /** Shows only the last 4 characters, e.g. "••••••••AbCd". */
    fun masked(): String {
        val k = getApiKey() ?: return ""
        return "•".repeat(8) + k.takeLast(4)
    }

    private companion object {
        const val KEY_API = "gemini_api_key"
    }
}
