package com.jarvis.assistant.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.assistant.AppViewModel
import com.jarvis.assistant.tasks.TaskStatus
import com.jarvis.assistant.ui.components.GlassPanel
import com.jarvis.assistant.ui.components.NeonButton
import com.jarvis.assistant.ui.components.ScreenFrame
import com.jarvis.assistant.ui.components.SectionLabel
import com.jarvis.assistant.ui.theme.JColors
import java.text.DateFormat
import java.util.Date

private fun statusColor(s: String) = when (s) {
    TaskStatus.DONE -> JColors.Ok
    TaskStatus.FAILED -> JColors.Danger
    TaskStatus.CANCELLED -> JColors.Warn
    TaskStatus.RUNNING -> JColors.Cyan
    else -> JColors.TextDim
}

@Composable
fun TasksScreen(vm: AppViewModel, onBack: () -> Unit) {
    val active by vm.activeTasks.collectAsStateWithLifecycle()
    val history by vm.taskHistory.collectAsStateWithLifecycle()
    val fmt = DateFormat.getTimeInstance(DateFormat.MEDIUM)

    ScreenFrame("Control Center", onBack) {
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp)) {
            item {
                SectionLabel("Running and queued (${active.size})")
                if (active.isEmpty()) Text("Nothing running. Up to 3 tasks run at the same time; extra ones wait in the queue.",
                    style = MaterialTheme.typography.bodySmall, color = JColors.TextDim)
                else NeonButton("Cancel all", { vm.cancelAllTasks() }, danger = true, icon = Icons.Filled.Close)
            }
            items(active, key = { "a${it.id}" }) { t ->
                GlassPanel(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(t.title, style = MaterialTheme.typography.bodyMedium, color = JColors.Text)
                            Text("${t.type} · ${t.status}${if (t.attempt > 1) " · attempt ${t.attempt}" else ""}",
                                style = MaterialTheme.typography.labelSmall, color = statusColor(t.status))
                        }
                        IconButton(onClick = { vm.cancelTask(t.id) }) { Icon(Icons.Filled.Close, "Cancel", tint = JColors.Danger) }
                    }
                }
            }
            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    SectionLabel("Task history", Modifier.weight(1f))
                    IconButton(onClick = { vm.clearTaskHistory() }) { Icon(Icons.Filled.DeleteSweep, "Clear history", tint = JColors.TextDim) }
                }
            }
            items(history, key = { "h${it.id}" }) { t ->
                Column(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                    Row {
                        Text(t.title, style = MaterialTheme.typography.bodyMedium, color = JColors.Text, modifier = Modifier.weight(1f))
                        Spacer(Modifier.width(8.dp))
                        Text(t.status, style = MaterialTheme.typography.labelSmall, color = statusColor(t.status))
                    }
                    Text("${t.type} · ${fmt.format(Date(t.startedAt))}${if (t.detail.isNotBlank()) " · ${t.detail}" else ""}",
                        style = MaterialTheme.typography.bodySmall, color = JColors.TextDim)
                }
            }
        }
    }
}
