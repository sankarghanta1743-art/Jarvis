package com.jarvis.assistant.commands

import kotlin.math.pow

/** Small, safe expression evaluator: + - * / ^ % and parentheses. No code execution. */
object Calculator {

    fun eval(expression: String): Double? = try {
        val p = Parser(expression)
        val v = p.parseExpression()
        if (p.hasMore()) null else v.takeIf { it.isFinite() }
    } catch (e: Exception) {
        null
    }

    fun format(v: Double): String =
        if (v == v.toLong().toDouble() && kotlin.math.abs(v) < 1e15) v.toLong().toString()
        else "%.6f".format(v).trimEnd('0').trimEnd('.')

    private class Parser(src: String) {
        private val s = src.replace(" ", "")
        private var pos = 0

        fun hasMore() = pos < s.length

        fun parseExpression(): Double {
            var v = parseTerm()
            while (pos < s.length && (s[pos] == '+' || s[pos] == '-')) {
                val op = s[pos++]
                val r = parseTerm()
                v = if (op == '+') v + r else v - r
            }
            return v
        }

        private fun parseTerm(): Double {
            var v = parsePower()
            while (pos < s.length && (s[pos] == '*' || s[pos] == '/' || s[pos] == '%')) {
                val op = s[pos++]
                val r = parsePower()
                v = when (op) {
                    '*' -> v * r
                    '/' -> v / r
                    else -> v % r
                }
            }
            return v
        }

        private fun parsePower(): Double {
            val base = parseUnary()
            return if (pos < s.length && s[pos] == '^') {
                pos++
                base.pow(parsePower())
            } else base
        }

        private fun parseUnary(): Double {
            if (pos < s.length && s[pos] == '-') { pos++; return -parseUnary() }
            if (pos < s.length && s[pos] == '+') { pos++; return parseUnary() }
            return parseAtom()
        }

        private fun parseAtom(): Double {
            if (pos < s.length && s[pos] == '(') {
                pos++
                val v = parseExpression()
                require(pos < s.length && s[pos] == ')')
                pos++
                return v
            }
            val start = pos
            while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
            require(pos > start)
            return s.substring(start, pos).toDouble()
        }
    }
}
