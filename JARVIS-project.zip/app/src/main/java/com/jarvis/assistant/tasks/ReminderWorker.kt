package com.jarvis.assistant.tasks

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.MainActivity
import com.jarvis.assistant.R
import java.util.concurrent.TimeUnit

/** Fires a notification when a reminder is due. */
class ReminderWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        val id = inputData.getLong(KEY_ID, -1)
        if (id < 0) return Result.failure()
        val app = applicationContext as JarvisApp
        val reminder = app.db.reminders().get(id) ?: return Result.success()
        if (reminder.done) return Result.success()

        ensureChannel(applicationContext)
        val canNotify = Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

        if (canNotify) {
            val open = PendingIntent.getActivity(
                applicationContext, 0,
                Intent(applicationContext, MainActivity::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val n = NotificationCompat.Builder(applicationContext, CHANNEL)
                .setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle("J.A.R.V.I.S. reminder")
                .setContentText(reminder.text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(reminder.text))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(open)
                .build()
            runCatching { NotificationManagerCompat.from(applicationContext).notify(id.toInt(), n) }
        }
        app.db.reminders().markDone(id)
        return Result.success()
    }

    companion object {
        const val KEY_ID = "reminder_id"
        const val CHANNEL = "jarvis_reminders"

        fun ensureChannel(ctx: Context) {
            if (Build.VERSION.SDK_INT >= 26) {
                val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                if (nm.getNotificationChannel(CHANNEL) == null) {
                    nm.createNotificationChannel(
                        NotificationChannel(CHANNEL, "Reminders", NotificationManager.IMPORTANCE_HIGH)
                    )
                }
            }
        }

        /** Android may delay background work slightly (battery saver / Doze), so timing is approximate. */
        fun schedule(ctx: Context, reminderId: Long, triggerAt: Long) {
            val delay = (triggerAt - System.currentTimeMillis()).coerceAtLeast(0)
            val req = OneTimeWorkRequestBuilder<ReminderWorker>()
                .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                .setInputData(Data.Builder().putLong(KEY_ID, reminderId).build())
                .build()
            WorkManager.getInstance(ctx).enqueueUniqueWork("reminder_$reminderId", ExistingWorkPolicy.REPLACE, req)
        }

        fun cancel(ctx: Context, reminderId: Long) {
            WorkManager.getInstance(ctx).cancelUniqueWork("reminder_$reminderId")
        }
    }
}
