package com.jarvis.assistant

import android.app.Application
import com.jarvis.assistant.ai.GeminiClient
import com.jarvis.assistant.data.JarvisDatabase
import com.jarvis.assistant.data.SecureKeyStore
import com.jarvis.assistant.data.SettingsStore
import com.jarvis.assistant.device.DeviceController
import com.jarvis.assistant.tasks.ReminderWorker
import com.jarvis.assistant.tasks.TaskEngine

/** Holds the app-wide singletons. Everything is created lazily. */
class JarvisApp : Application() {
    val db by lazy { JarvisDatabase.create(this) }
    val keyStore by lazy { SecureKeyStore(this) }
    val settings by lazy { SettingsStore(this) }
    val gemini by lazy { GeminiClient(keyStore) }
    val device by lazy { DeviceController(this) }
    val tasks by lazy { TaskEngine(db.tasks()) }

    override fun onCreate() {
        super.onCreate()
        ReminderWorker.ensureChannel(this)
    }
}
