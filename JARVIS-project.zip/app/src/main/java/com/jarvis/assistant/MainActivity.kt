package com.jarvis.assistant

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.jarvis.assistant.ui.screens.ApiSettingsScreen
import com.jarvis.assistant.ui.screens.AppSettingsScreen
import com.jarvis.assistant.ui.screens.ChatScreen
import com.jarvis.assistant.ui.screens.DashboardScreen
import com.jarvis.assistant.ui.screens.DeviceScreen
import com.jarvis.assistant.ui.screens.HistoryScreen
import com.jarvis.assistant.ui.screens.NotesScreen
import com.jarvis.assistant.ui.screens.RemindersScreen
import com.jarvis.assistant.ui.screens.TasksScreen
import com.jarvis.assistant.ui.screens.VoiceScreen
import com.jarvis.assistant.ui.screens.VoiceSettingsScreen
import com.jarvis.assistant.ui.theme.JColors
import com.jarvis.assistant.ui.theme.JarvisTheme
import com.jarvis.assistant.voice.ListenState

class MainActivity : ComponentActivity() {

    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { JarvisTheme { JarvisRoot(vm) } }
    }

    override fun onStop() {
        // Speech recognition only works while the app is on screen.
        vm.stopVoice()
        super.onStop()
    }
}

@Composable
private fun JarvisRoot(vm: AppViewModel) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val nav = rememberNavController()
    val listenState by vm.listenState.collectAsStateWithLifecycle()
    val session by vm.sessionActive.collectAsStateWithLifecycle()
    val confirm by vm.confirm.collectAsStateWithLifecycle()

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.startVoice()
        else Toast.makeText(ctx, "Microphone permission is needed for voice. You can still type.", Toast.LENGTH_LONG).show()
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    LaunchedEffect(Unit) {
        // Needed on Android 13+ for reminder notifications; Android 10 has no such prompt.
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    LaunchedEffect(Unit) {
        vm.toasts.collect { Toast.makeText(ctx, it, Toast.LENGTH_SHORT).show() }
    }

    val onMic: () -> Unit = {
        if (listenState != ListenState.IDLE || session) {
            vm.stopVoice()
        } else if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            vm.startVoice()
        } else {
            micLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }
    val back: () -> Unit = { nav.popBackStack() }

    NavHost(
        navController = nav,
        startDestination = "dashboard",
        enterTransition = { slideInHorizontally { it / 4 } + fadeIn() },
        exitTransition = { fadeOut() },
        popEnterTransition = { fadeIn() },
        popExitTransition = { slideOutHorizontally { it / 4 } + fadeOut() }
    ) {
        composable("dashboard") { DashboardScreen(vm, { nav.navigate(it) { launchSingleTop = true } }, onMic) }
        composable("chat") { ChatScreen(vm, back, onMic) }
        composable("voice") { VoiceScreen(vm, back, onMic) }
        composable("tasks") { TasksScreen(vm, back) }
        composable("device") { DeviceScreen(vm, back) }
        composable("notes") { NotesScreen(vm, back) }
        composable("reminders") { RemindersScreen(vm, back) }
        composable("history") { HistoryScreen(vm, back) { nav.navigate("chat") { launchSingleTop = true } } }
        composable("api") { ApiSettingsScreen(vm, back) }
        composable("voicesettings") { VoiceSettingsScreen(vm, back) }
        composable("settings") { AppSettingsScreen(vm, back) }
    }

    confirm?.let { c ->
        AlertDialog(
            onDismissRequest = { vm.dismissConfirm() },
            containerColor = androidx.compose.ui.graphics.Color(0xFF05121A),
            title = { Text(c.title, color = JColors.Cyan) },
            text = { Text(c.message, color = JColors.Text) },
            confirmButton = { TextButton({ vm.runConfirmed() }) { Text("Confirm", color = JColors.Cyan) } },
            dismissButton = { TextButton({ vm.dismissConfirm() }) { Text("Cancel", color = JColors.TextDim) } }
        )
    }
}
