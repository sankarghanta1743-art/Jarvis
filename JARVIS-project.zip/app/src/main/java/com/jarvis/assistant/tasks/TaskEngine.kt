package com.jarvis.assistant.tasks

import com.jarvis.assistant.data.TaskDao
import com.jarvis.assistant.data.TaskRecord
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap

object TaskStatus {
    const val QUEUED = "QUEUED"
    const val RUNNING = "RUNNING"
    const val DONE = "DONE"
    const val FAILED = "FAILED"
    const val CANCELLED = "CANCELLED"
}

data class ActiveTask(
    val id: Long,
    val title: String,
    val type: String,
    val status: String,
    val attempt: Int = 1
)

/**
 * Runs independent jobs in parallel (max [maxParallel] at once), queues the rest,
 * supports cancellation and automatic retry, and records every task in the database.
 * Nothing here runs on the main thread.
 */
class TaskEngine(private val dao: TaskDao, maxParallel: Int = 3) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val gate = Semaphore(maxParallel)
    private val jobs = ConcurrentHashMap<Long, Job>()

    private val _active = MutableStateFlow<List<ActiveTask>>(emptyList())
    val active: StateFlow<List<ActiveTask>> = _active.asStateFlow()

    init {
        // Tasks left over from a previous run can never finish; mark them cancelled.
        scope.launch { dao.cancelStale() }
    }

    /**
     * Queues [block]. It returns a short result text that is saved as the task detail.
     * If it throws, it is retried up to [retries] more times with a growing delay.
     */
    suspend fun submit(
        title: String,
        type: String,
        retries: Int = 0,
        block: suspend () -> String
    ): Long {
        val id = dao.insert(TaskRecord(title = title, type = type, status = TaskStatus.QUEUED))
        setActive(ActiveTask(id, title, type, TaskStatus.QUEUED))

        val job = scope.launch(start = CoroutineStart.LAZY) {
            try {
                gate.withPermit {
                    var attempt = 1
                    while (true) {
                        updateStatus(id, TaskStatus.RUNNING, attempt)
                        dao.setStatus(id, TaskStatus.RUNNING)
                        try {
                            val detail = block()
                            finish(id, TaskStatus.DONE, detail)
                            return@withPermit
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            if (attempt > retries) {
                                finish(id, TaskStatus.FAILED, e.message?.take(200) ?: "Task failed")
                                return@withPermit
                            }
                            attempt++
                            delay(1000L * attempt)
                        }
                    }
                }
            } catch (e: CancellationException) {
                withContext(NonCancellable) { finish(id, TaskStatus.CANCELLED, "Cancelled by user") }
                throw e
            } finally {
                jobs.remove(id)
            }
        }
        jobs[id] = job
        job.start()
        return id
    }

    fun cancel(id: Long) {
        jobs[id]?.cancel()
    }

    fun cancelAll() {
        jobs.values.forEach { it.cancel() }
    }

    suspend fun clearHistory() = dao.clear()

    private suspend fun finish(id: Long, status: String, detail: String) {
        dao.finish(id, status, detail, System.currentTimeMillis())
        _active.update { list -> list.filterNot { it.id == id } }
    }

    private fun setActive(t: ActiveTask) = _active.update { it + t }

    private fun updateStatus(id: Long, status: String, attempt: Int) =
        _active.update { list -> list.map { if (it.id == id) it.copy(status = status, attempt = attempt) else it } }
}
