package com.jarvis.assistant.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

object JColors {
    val Black = Color(0xFF000000)
    val Cyan = Color(0xFF00E5FF)
    val Blue = Color(0xFF2979FF)
    val DeepBlue = Color(0xFF0D47A1)
    val Text = Color(0xFFE0F7FF)
    val TextDim = Color(0xFF7FA8B8)
    val Ok = Color(0xFF00E676)
    val Warn = Color(0xFFFFB300)
    val Danger = Color(0xFFFF5252)
    val Glass = Color(0x1000E5FF)
    val GlassStrong = Color(0x2200E5FF)
}

private val scheme = darkColorScheme(
    primary = JColors.Cyan,
    onPrimary = JColors.Black,
    secondary = JColors.Blue,
    onSecondary = JColors.Black,
    background = JColors.Black,
    onBackground = JColors.Text,
    surface = JColors.Black,
    onSurface = JColors.Text,
    surfaceVariant = Color(0xFF06141C),
    onSurfaceVariant = JColors.TextDim,
    outline = Color(0x6600E5FF),
    error = JColors.Danger
)

/** Monospace + wide letter spacing gives the "robotic" look without needing font files. */
private val Mono = FontFamily.Monospace

private val typography = Typography(
    displayLarge = TextStyle(fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 34.sp, letterSpacing = 6.sp),
    headlineMedium = TextStyle(fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 22.sp, letterSpacing = 3.sp),
    titleLarge = TextStyle(fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 18.sp, letterSpacing = 3.sp),
    titleMedium = TextStyle(fontFamily = Mono, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, letterSpacing = 1.5.sp),
    bodyLarge = TextStyle(fontFamily = Mono, fontSize = 15.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontFamily = Mono, fontSize = 13.sp, lineHeight = 19.sp),
    bodySmall = TextStyle(fontFamily = Mono, fontSize = 11.sp, lineHeight = 15.sp),
    labelLarge = TextStyle(fontFamily = Mono, fontWeight = FontWeight.Bold, fontSize = 13.sp, letterSpacing = 2.sp),
    labelMedium = TextStyle(fontFamily = Mono, fontSize = 11.sp, letterSpacing = 2.sp),
    labelSmall = TextStyle(fontFamily = Mono, fontSize = 10.sp, letterSpacing = 1.5.sp)
)

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, typography = typography, content = content)
}
