package com.jarvis.assistant.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversations ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<Conversation>>

    @Query("SELECT * FROM conversations WHERE id = :id")
    suspend fun get(id: Long): Conversation?

    @Insert
    suspend fun insert(c: Conversation): Long

    @Query("UPDATE conversations SET updatedAt = :time, title = :title WHERE id = :id")
    suspend fun touch(id: Long, title: String, time: Long = System.currentTimeMillis())

    @Query("DELETE FROM conversations WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM conversations")
    suspend fun deleteAll()
}

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE conversationId = :cid ORDER BY timestamp ASC, id ASC")
    fun observe(cid: Long): Flow<List<ChatMessage>>

    @Query("SELECT * FROM messages WHERE conversationId = :cid ORDER BY timestamp DESC, id DESC LIMIT :limit")
    suspend fun recent(cid: Long, limit: Int): List<ChatMessage>

    @Insert
    suspend fun insert(m: ChatMessage): Long
}

@Dao
interface NoteDao {
    @Query("SELECT * FROM notes ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<Note>>

    @Insert
    suspend fun insert(n: Note): Long

    @Update
    suspend fun update(n: Note)

    @Delete
    suspend fun delete(n: Note)
}

@Dao
interface ReminderDao {
    @Query("SELECT * FROM reminders ORDER BY triggerAt ASC")
    fun observeAll(): Flow<List<Reminder>>

    @Query("SELECT * FROM reminders WHERE id = :id")
    suspend fun get(id: Long): Reminder?

    @Insert
    suspend fun insert(r: Reminder): Long

    @Query("UPDATE reminders SET done = 1 WHERE id = :id")
    suspend fun markDone(id: Long)

    @Query("DELETE FROM reminders WHERE id = :id")
    suspend fun delete(id: Long)
}

@Dao
interface TaskDao {
    @Query("SELECT * FROM task_history ORDER BY startedAt DESC LIMIT 200")
    fun observeAll(): Flow<List<TaskRecord>>

    @Insert
    suspend fun insert(t: TaskRecord): Long

    @Query("UPDATE task_history SET status = :status, detail = :detail, finishedAt = :finishedAt WHERE id = :id")
    suspend fun finish(id: Long, status: String, detail: String, finishedAt: Long?)

    @Query("UPDATE task_history SET status = :status WHERE id = :id")
    suspend fun setStatus(id: Long, status: String)

    @Query("UPDATE task_history SET status = 'CANCELLED', finishedAt = :now WHERE status IN ('QUEUED','RUNNING')")
    suspend fun cancelStale(now: Long = System.currentTimeMillis())

    @Query("DELETE FROM task_history")
    suspend fun clear()
}
