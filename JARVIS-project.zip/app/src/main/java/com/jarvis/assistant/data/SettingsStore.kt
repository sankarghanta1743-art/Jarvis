package com.jarvis.assistant.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "jarvis_settings")

/** Checked against Google's deprecation page on 2026-11-01. gemini-2.0-flash was shut down June 2026. */
const val DEFAULT_MODEL = "gemini-3.8-flash"
val SUGGESTED_MODELS = listOf("gemini-3.8-flash", "gemini-3.5-flash-lite", "gemini-2.5-flash")

data class AppSettings(
    /** "en", "hi" or "bn" */
    val language: String = "en",
    val model: String = DEFAULT_MODEL,
    val speechRate: Float = 1.0f,
    val pitch: Float = 0.8f,
    val preferMaleVoice: Boolean = true,
    val speakReplies: Boolean = true,
    val continuousMode: Boolean = false,
    val wakeWordEnabled: Boolean = false,
    val muted: Boolean = false,
    val saveHistory: Boolean = true,
    val notificationReading: Boolean = false
)

class SettingsStore(private val context: Context) {

    private object K {
        val language = stringPreferencesKey("language")
        val model = stringPreferencesKey("model")
        val speechRate = floatPreferencesKey("speech_rate")
        val pitch = floatPreferencesKey("pitch")
        val male = booleanPreferencesKey("male_voice")
        val speak = booleanPreferencesKey("speak_replies")
        val continuous = booleanPreferencesKey("continuous")
        val wake = booleanPreferencesKey("wake_word")
        val muted = booleanPreferencesKey("muted")
        val history = booleanPreferencesKey("save_history")
        val notif = booleanPreferencesKey("notif_reading")
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map { p -> p.toSettings() }

    private fun Preferences.toSettings(): AppSettings {
        val d = AppSettings()
        return AppSettings(
            language = this[K.language] ?: d.language,
            model = this[K.model] ?: d.model,
            speechRate = this[K.speechRate] ?: d.speechRate,
            pitch = this[K.pitch] ?: d.pitch,
            preferMaleVoice = this[K.male] ?: d.preferMaleVoice,
            speakReplies = this[K.speak] ?: d.speakReplies,
            continuousMode = this[K.continuous] ?: d.continuousMode,
            wakeWordEnabled = this[K.wake] ?: d.wakeWordEnabled,
            muted = this[K.muted] ?: d.muted,
            saveHistory = this[K.history] ?: d.saveHistory,
            notificationReading = this[K.notif] ?: d.notificationReading
        )
    }

    suspend fun setLanguage(v: String) = context.dataStore.edit { it[K.language] = v }
    suspend fun setModel(v: String) = context.dataStore.edit { it[K.model] = v }
    suspend fun setSpeechRate(v: Float) = context.dataStore.edit { it[K.speechRate] = v }
    suspend fun setPitch(v: Float) = context.dataStore.edit { it[K.pitch] = v }
    suspend fun setMaleVoice(v: Boolean) = context.dataStore.edit { it[K.male] = v }
    suspend fun setSpeakReplies(v: Boolean) = context.dataStore.edit { it[K.speak] = v }
    suspend fun setContinuous(v: Boolean) = context.dataStore.edit { it[K.continuous] = v }
    suspend fun setWakeWord(v: Boolean) = context.dataStore.edit { it[K.wake] = v }
    suspend fun setMuted(v: Boolean) = context.dataStore.edit { it[K.muted] = v }
    suspend fun setSaveHistory(v: Boolean) = context.dataStore.edit { it[K.history] = v }
    suspend fun setNotificationReading(v: Boolean) = context.dataStore.edit { it[K.notif] = v }
}
