package com.jarvis.assistant.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.assistant.AppViewModel
import com.jarvis.assistant.ui.components.AudioWaveform
import com.jarvis.assistant.ui.components.CoreState
import com.jarvis.assistant.ui.components.GlassPanel
import com.jarvis.assistant.ui.components.JarvisCore
import com.jarvis.assistant.ui.components.NeonButton
import com.jarvis.assistant.ui.components.ScreenFrame
import com.jarvis.assistant.ui.components.SectionLabel
import com.jarvis.assistant.ui.components.SwitchRow
import com.jarvis.assistant.ui.theme.JColors

@Composable
fun VoiceScreen(vm: AppViewModel, onBack: () -> Unit, onMic: () -> Unit) {
    val core = coreStateOf(vm)
    val level by vm.micLevel.collectAsStateWithLifecycle()
    val partial by vm.partialText.collectAsStateWithLifecycle()
    val session by vm.sessionActive.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val messages by vm.messages.collectAsStateWithLifecycle()
    val ttsNote by vm.ttsNote.collectAsStateWithLifecycle()

    ScreenFrame("Voice Assistant", onBack) {
        Column(
            Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            JarvisCore(core, level)
            Text(statusText(core, session), style = MaterialTheme.typography.titleMedium, color = JColors.Cyan)
            Text(
                partial.ifBlank { messages.lastOrNull { it.role == "user" }?.text ?: "Tap LISTEN and speak." },
                style = MaterialTheme.typography.bodyMedium, color = JColors.TextDim, textAlign = TextAlign.Center,
                modifier = Modifier.padding(vertical = 6.dp)
            )
            AudioWaveform(level, core == CoreState.LISTENING || core == CoreState.SPEAKING)

            Row(
                Modifier.padding(top = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                NeonButton("Listen", onMic, icon = Icons.Filled.Mic)
                NeonButton("Stop", { vm.stopVoice() }, icon = Icons.Filled.Stop, danger = true)
                NeonButton("Hush", { vm.interruptSpeech() }, icon = Icons.Filled.VolumeOff)
            }

            if (ttsNote.isNotBlank()) {
                Text(ttsNote, style = MaterialTheme.typography.bodySmall, color = JColors.Warn,
                    modifier = Modifier.padding(top = 10.dp))
            }

            SectionLabel("Session mode", Modifier.fillMaxWidth())
            GlassPanel(Modifier.fillMaxWidth()) {
                SwitchRow("Continuous conversation", "After JARVIS answers, listen again automatically.",
                    settings.continuousMode) { vm.setContinuous(it) }
                SwitchRow("Wake word: \"Hey JARVIS\"", "Only works while this app is open on screen. Android 10 does not allow a safe always-on microphone for third-party apps.",
                    settings.wakeWordEnabled) { vm.setWakeWord(it) }
                SwitchRow("Mute voice replies", "JARVIS answers in text only.", settings.muted) { vm.setMuted(it) }
            }

            SectionLabel("Things you can say", Modifier.fillMaxWidth())
            GlassPanel(Modifier.fillMaxWidth()) {
                listOf(
                    "Hey JARVIS",
                    "Open YouTube / Open Chrome",
                    "What time is it?",
                    "Search the internet for …",
                    "Turn on / off flashlight",
                    "Create a note: buy milk",
                    "Remind me in 10 minutes to call mom",
                    "Calculate 25 times 4",
                    "Volume up / volume 50",
                    "Mute / Unmute / Stop speaking",
                    "Anything else goes to Gemini"
                ).forEach { Text("› $it", style = MaterialTheme.typography.bodySmall, color = JColors.Text, modifier = Modifier.padding(vertical = 2.dp)) }
            }
            Text(
                "Local commands reply in English. Gemini answers follow your chosen language.",
                style = MaterialTheme.typography.bodySmall, color = JColors.TextDim,
                modifier = Modifier.padding(top = 8.dp).fillMaxWidth()
            )
        }
    }
}
