package com.jarvis.assistant

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.assistant.ai.AiResult
import com.jarvis.assistant.ai.AiTurn
import com.jarvis.assistant.ai.Prompts
import com.jarvis.assistant.commands.Calculator
import com.jarvis.assistant.commands.Command
import com.jarvis.assistant.commands.CommandParser
import com.jarvis.assistant.data.AppSettings
import com.jarvis.assistant.data.ChatMessage
import com.jarvis.assistant.data.Conversation
import com.jarvis.assistant.data.Note
import com.jarvis.assistant.data.Reminder
import com.jarvis.assistant.data.TaskRecord
import com.jarvis.assistant.device.JarvisNotificationService
import com.jarvis.assistant.tasks.ActiveTask
import com.jarvis.assistant.tasks.ReminderWorker
import com.jarvis.assistant.voice.ListenState
import com.jarvis.assistant.voice.VoiceEvent
import com.jarvis.assistant.voice.VoiceManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

data class DeviceStatus(
    val battery: Int = 0,
    val charging: Boolean = false,
    val network: String = "--",
    val time: String = "",
    val date: String = ""
)

data class ConfirmRequest(val title: String, val message: String, val action: () -> Unit)

private data class Reply(val text: String, val speak: Boolean = true, val relisten: Boolean = false)

private enum class Awaiting { NOTE, CALC, SEARCH }

@OptIn(ExperimentalCoroutinesApi::class)
class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as JarvisApp
    private val db get() = app.db
    private val device get() = app.device

    val voice = VoiceManager(application)

    // ---------------- observable state ----------------

    val settings: StateFlow<AppSettings> =
        app.settings.settings.stateIn(viewModelScope, SharingStarted.Eagerly, AppSettings())

    private val _hasKey = MutableStateFlow(false)
    val hasKey: StateFlow<Boolean> = _hasKey.asStateFlow()
    private val _maskedKey = MutableStateFlow("")
    val maskedKey: StateFlow<String> = _maskedKey.asStateFlow()
    private val _keyTestMsg = MutableStateFlow<String?>(null)
    val keyTestMsg: StateFlow<String?> = _keyTestMsg.asStateFlow()
    private val _keyTesting = MutableStateFlow(false)
    val keyTesting: StateFlow<Boolean> = _keyTesting.asStateFlow()

    private val _currentConv = MutableStateFlow<Long?>(null)
    val currentConversationId: StateFlow<Long?> = _currentConv.asStateFlow()

    val messages: StateFlow<List<ChatMessage>> = _currentConv
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else db.messages().observe(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val conversations: StateFlow<List<Conversation>> =
        db.conversations().observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val notes: StateFlow<List<Note>> =
        db.notes().observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val reminders: StateFlow<List<Reminder>> =
        db.reminders().observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val taskHistory: StateFlow<List<TaskRecord>> =
        db.tasks().observeAll().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeTasks: StateFlow<List<ActiveTask>> = app.tasks.active
    val thinking: StateFlow<Boolean> =
        activeTasks.map { list -> list.any { it.type == "AI" } }
            .stateIn(viewModelScope, SharingStarted.Eagerly, false)

    val torchOn: StateFlow<Boolean> = device.torchOn
    val listenState: StateFlow<ListenState> = voice.listenState
    val partialText: StateFlow<String> = voice.partial
    val micLevel: StateFlow<Float> = voice.level
    val speaking: StateFlow<Boolean> = voice.speaking
    val ttsNote: StateFlow<String> = voice.ttsNote

    private val _status = MutableStateFlow(DeviceStatus())
    val status: StateFlow<DeviceStatus> = _status.asStateFlow()

    private val _session = MutableStateFlow(false)
    /** True while continuous mode or wake-word listening is running. */
    val sessionActive: StateFlow<Boolean> = _session.asStateFlow()

    private val _confirm = MutableStateFlow<ConfirmRequest?>(null)
    val confirm: StateFlow<ConfirmRequest?> = _confirm.asStateFlow()

    private val _chatError = MutableStateFlow<String?>(null)
    val chatError: StateFlow<String?> = _chatError.asStateFlow()

    private val _toasts = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val toasts: SharedFlow<String> = _toasts.asSharedFlow()

    private val _notifAccess = MutableStateFlow(false)
    val notificationAccessGranted: StateFlow<Boolean> = _notifAccess.asStateFlow()

    // ---------------- internal state ----------------

    private var continuousActive = false
    private var wakeLoopActive = false
    private var relistenAfterSpeech = false
    private var silentCount = 0
    private var awaiting: Awaiting? = null
    private var listenJob: Job? = null

    init {
        // Load key info off the main thread (Android Keystore can be slow the first time).
        viewModelScope.launch(Dispatchers.IO) { refreshKey() }

        // Keep the voice engine in sync with settings.
        viewModelScope.launch {
            settings.collect { s ->
                voice.rate = s.speechRate
                voice.pitch = s.pitch
                voice.preferMale = s.preferMaleVoice
                voice.muted = s.muted
                JarvisNotificationService.allowCapture = s.notificationReading
            }
        }

        // Privacy: when "save history" is off, old conversations are erased at launch.
        viewModelScope.launch {
            val s = app.settings.settings.first()
            if (!s.saveHistory) db.conversations().deleteAll()
        }

        // Clock + status ticker.
        viewModelScope.launch {
            var tick = 0
            while (true) {
                val old = _status.value
                val now = Date()
                _status.value = if (tick % 10 == 0) {
                    val b = device.battery()
                    DeviceStatus(b.percent, b.charging, device.networkStatus(),
                        DateFormat.getTimeInstance(DateFormat.MEDIUM).format(now),
                        DateFormat.getDateInstance(DateFormat.MEDIUM).format(now))
                } else {
                    old.copy(time = DateFormat.getTimeInstance(DateFormat.MEDIUM).format(now))
                }
                _notifAccess.value = device.hasNotificationAccess()
                tick++
                delay(1000)
            }
        }

        // Continuous conversation: listen again once the assistant finishes speaking.
        viewModelScope.launch {
            var was = false
            voice.speaking.collect { now ->
                if (was && !now && relistenAfterSpeech) {
                    relistenAfterSpeech = false
                    listenSoon(400)
                }
                was = now
            }
        }

        viewModelScope.launch {
            voice.events.collect { ev ->
                when (ev) {
                    is VoiceEvent.Final -> onVoiceFinal(ev.text)
                    is VoiceEvent.Error -> onVoiceError(ev)
                }
            }
        }
    }

    private fun refreshKey() {
        _hasKey.value = app.keyStore.hasApiKey()
        _maskedKey.value = app.keyStore.masked()
    }

    private fun toast(msg: String) { _toasts.tryEmit(msg) }

    // ---------------- API key ----------------

    fun saveApiKey(key: String) {
        if (key.isBlank()) { toast("Paste your API key first."); return }
        viewModelScope.launch(Dispatchers.IO) {
            app.keyStore.saveApiKey(key)
            refreshKey()
            _keyTestMsg.value = null
            toast("API key saved securely.")
        }
    }

    fun deleteApiKey() {
        viewModelScope.launch(Dispatchers.IO) {
            app.keyStore.deleteApiKey()
            refreshKey()
            _keyTestMsg.value = null
            toast("API key deleted.")
        }
    }

    /** Tests [candidate] if given, otherwise the saved key. */
    fun testApiKey(candidate: String?) {
        viewModelScope.launch {
            _keyTesting.value = true
            _keyTestMsg.value = null
            val err = withContext(Dispatchers.IO) { app.gemini.testKey(candidate) }
            _keyTestMsg.value = err ?: "✔ The key works."
            _keyTesting.value = false
        }
    }

    // ---------------- conversations ----------------

    fun newChat() { _currentConv.value = null; _chatError.value = null }

    fun openConversation(id: Long) { _currentConv.value = id; _chatError.value = null }

    fun deleteConversation(id: Long) {
        viewModelScope.launch {
            db.conversations().delete(id)
            if (_currentConv.value == id) _currentConv.value = null
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            db.conversations().deleteAll()
            _currentConv.value = null
            toast("Conversation history deleted.")
        }
    }

    private suspend fun ensureConversation(firstText: String): Long {
        _currentConv.value?.let { return it }
        val id = db.conversations().insert(Conversation(title = firstText.take(40)))
        _currentConv.value = id
        return id
    }

    private suspend fun addMessage(cid: Long, role: String, text: String) {
        db.messages().insert(ChatMessage(conversationId = cid, role = role, text = text))
        val title = db.conversations().get(cid)?.title ?: "Chat"
        db.conversations().touch(cid, title)
    }

    // ---------------- input handling ----------------

    /** Entry point for typed or spoken input. */
    fun submitInput(raw: String) {
        val original = raw.trim()
        if (original.isEmpty()) return
        viewModelScope.launch {
            _chatError.value = null
            val (woke, clean) = CommandParser.stripWakeWord(original)

            val pending = awaiting
            awaiting = null
            val cmd: Command? = when {
                clean.isEmpty() -> if (woke) Command.WakeOnly else return@launch
                pending == Awaiting.NOTE -> Command.CreateNote(clean)
                pending == Awaiting.CALC -> CommandParser.parse("calculate $clean") ?: Command.Calculate(clean)
                pending == Awaiting.SEARCH -> Command.Search(clean)
                else -> CommandParser.parse(original)
            }

            val cid = ensureConversation(clean.ifEmpty { original })
            addMessage(cid, "user", original)

            if (cmd != null) {
                app.tasks.submit(describe(cmd), typeOf(cmd), retries = 0) {
                    val reply = execute(cmd)
                    deliverReply(cid, reply)
                    reply.text.take(120)
                }
            } else {
                askGemini(cid, clean)
            }
        }
    }

    private suspend fun askGemini(cid: Long, text: String) {
        app.tasks.submit("Ask Gemini: ${text.take(32)}", "AI", retries = 0) {
            val s = settings.value
            val history = db.messages().recent(cid, 20).reversed()
                .dropWhile { it.role == "model" }
                .map { AiTurn(it.role, it.text) }
            when (val r = app.gemini.generate(s.model, history, Prompts.system(s.language))) {
                is AiResult.Success -> {
                    deliverReply(cid, Reply(r.text))
                    "Answered (${r.text.length} chars)"
                }
                is AiResult.Failure -> {
                    _chatError.value = r.message
                    toast(r.message)
                    withContext(Dispatchers.Main) { afterReply(false) }
                    throw IllegalStateException(r.message)
                }
            }
        }
    }

    private suspend fun deliverReply(cid: Long, r: Reply) {
        if (r.text.isNotBlank()) addMessage(cid, "model", r.text)
        withContext(Dispatchers.Main) {
            val s = settings.value
            val willSpeak = r.speak && r.text.isNotBlank() && s.speakReplies && !s.muted
            if (willSpeak) voice.speak(r.text)
            afterReply(r.relisten, willSpeak)
        }
    }

    private fun afterReply(forceListen: Boolean, spoken: Boolean = false) {
        val want = forceListen || continuousActive || wakeLoopActive
        if (!want) return
        if (!spoken) {
            listenSoon(300)
        } else {
            relistenAfterSpeech = true
            // Safety net in case the speech engine never reports back.
            viewModelScope.launch {
                delay(4000)
                if (relistenAfterSpeech && !voice.speaking.value) {
                    relistenAfterSpeech = false
                    listenSoon(0)
                }
            }
        }
    }

    private fun listenSoon(delayMs: Long) {
        listenJob?.cancel()
        listenJob = viewModelScope.launch {
            delay(delayMs)
            if (voice.listenState.value == ListenState.IDLE && !voice.speaking.value) {
                voice.startListening(settings.value.language)
            }
        }
    }

    // ---------------- voice ----------------

    /** Call only after the microphone permission has been granted. */
    fun startVoice() {
        val s = settings.value
        continuousActive = s.continuousMode
        wakeLoopActive = s.wakeWordEnabled
        _session.value = continuousActive || wakeLoopActive
        silentCount = 0
        voice.startListening(s.language)
    }

    fun stopVoice() {
        continuousActive = false
        wakeLoopActive = false
        relistenAfterSpeech = false
        awaiting = null
        listenJob?.cancel()
        _session.value = false
        voice.stopListening()
    }

    fun interruptSpeech() { voice.stopSpeaking() }

    private fun onVoiceFinal(text: String) {
        silentCount = 0
        val (woke, _) = CommandParser.stripWakeWord(text)
        if (wakeLoopActive && !woke && awaiting == null) {
            listenSoon(300)   // ignore everything that does not start with "Hey JARVIS"
            return
        }
        submitInput(text)
    }

    private fun onVoiceError(ev: VoiceEvent.Error) {
        val sessionOn = continuousActive || wakeLoopActive
        if (ev.silent) {
            silentCount++
            if (sessionOn && silentCount < 30) listenSoon(400)
            else if (sessionOn) { stopVoice(); toast("Stopped listening after a quiet period.") }
        } else {
            toast(ev.message)
            stopVoice()
        }
    }

    // ---------------- local commands ----------------

    private fun describe(c: Command): String = when (c) {
        is Command.OpenApp -> "Open ${c.name}"
        Command.OpenCamera -> "Open camera"
        Command.OpenSettings -> "Open settings"
        is Command.OpenUrl -> "Open ${c.url}"
        Command.Time -> "Tell the time"
        Command.Date -> "Tell the date"
        Command.Battery -> "Check battery"
        is Command.Flashlight -> "Flashlight ${if (c.on) "on" else "off"}"
        is Command.Search -> "Search: ${c.query.take(30)}"
        is Command.CreateNote -> "Create note"
        is Command.SetReminder -> "Set reminder"
        is Command.Calculate -> "Calculate"
        is Command.Volume -> "Change volume"
        is Command.Call -> "Call ${c.number}"
        Command.ReadNotifications -> "Read notifications"
        Command.WakeOnly -> "Wake word"
        Command.StopSpeaking -> "Stop speaking"
        Command.Mute -> "Mute voice"
        Command.Unmute -> "Unmute voice"
    }

    private fun typeOf(c: Command): String = when (c) {
        is Command.CreateNote -> "NOTE"
        is Command.SetReminder -> "REMINDER"
        is Command.Search -> "SEARCH"
        else -> "DEVICE"
    }

    private suspend fun execute(c: Command): Reply = when (c) {
        Command.WakeOnly -> Reply("Yes, I'm listening.", relisten = true)
        Command.StopSpeaking -> { withContext(Dispatchers.Main) { voice.stopSpeaking() }; Reply("Okay.", speak = false) }
        Command.Mute -> {
            app.settings.setMuted(true)
            withContext(Dispatchers.Main) { voice.muted = true; voice.stopSpeaking() }
            Reply("Voice muted. I will reply in text only.", speak = false)
        }
        Command.Unmute -> {
            app.settings.setMuted(false)
            withContext(Dispatchers.Main) { voice.muted = false }
            Reply("Voice is back on.")
        }
        is Command.OpenApp -> {
            val label = device.openApp(c.name)
            if (label != null) Reply("Opening $label.") else Reply("I couldn't find an app called ${c.name}.")
        }
        Command.OpenCamera -> if (device.openCamera()) Reply("Opening the camera.") else Reply("I couldn't open the camera.")
        Command.OpenSettings -> if (device.openSettings()) Reply("Opening settings.") else Reply("I couldn't open settings.")
        is Command.OpenUrl -> if (device.openWebsite(c.url)) Reply("Opening ${c.url}.") else Reply("I couldn't open that website.")
        Command.Time -> Reply("It's ${device.timeText()}.")
        Command.Date -> Reply("Today is ${device.dateText()}.")
        Command.Battery -> {
            val b = device.battery()
            Reply("Battery is at ${b.percent} percent${if (b.charging) " and charging" else ""}.")
        }
        is Command.Flashlight -> when {
            !device.hasFlashlight -> Reply("This phone has no flashlight I can control.")
            device.setFlashlight(c.on) -> Reply("Flashlight ${if (c.on) "on" else "off"}.")
            else -> Reply("I couldn't change the flashlight. Another app may be using the camera.")
        }
        is Command.Search -> {
            if (c.query.isBlank()) {
                awaiting = Awaiting.SEARCH
                Reply("What should I search for?", relisten = true)
            } else if (device.webSearch(c.query)) Reply("Searching the web for ${c.query}.")
            else Reply("I couldn't open the browser.")
        }
        is Command.CreateNote -> {
            if (c.text.isBlank()) {
                awaiting = Awaiting.NOTE
                Reply("What should the note say?", relisten = true)
            } else {
                db.notes().insert(Note(title = c.text.take(30), content = c.text))
                Reply("Note saved.")
            }
        }
        is Command.SetReminder -> {
            val at = System.currentTimeMillis() + c.delayMinutes * 60_000L
            val id = db.reminders().insert(Reminder(text = c.text, triggerAt = at))
            ReminderWorker.schedule(getApplication(), id, at)
            val whenText = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(at))
            if (c.timeGiven) Reply("Reminder set for $whenText: ${c.text}.")
            else Reply("You didn't give a time, so I set it for 30 minutes from now, at $whenText.")
        }
        is Command.Calculate -> {
            if (c.expression.isBlank()) {
                awaiting = Awaiting.CALC
                Reply("What should I calculate?", relisten = true)
            } else {
                val v = Calculator.eval(c.expression)
                if (v == null) Reply("Sorry, I couldn't calculate that.")
                else Reply("${c.expression.trim()} equals ${Calculator.format(v)}.")
            }
        }
        is Command.Volume -> {
            val ok = when {
                c.percent != null -> device.setVolumePercent(c.percent)
                c.up != null -> device.changeVolume(c.up)
                else -> false
            }
            if (ok) Reply("Volume is at ${device.volumePercent()} percent.") else Reply("I couldn't change the volume.")
        }
        is Command.Call -> {
            _confirm.value = ConfirmRequest(
                "Open dialer?",
                "J.A.R.V.I.S. will open the phone dialer with ${c.number}. You still have to press the call button yourself."
            ) { device.openDialer(c.number) }
            Reply("Please confirm on screen before I open the dialer.", speak = false)
        }
        Command.ReadNotifications -> {
            val s = settings.value
            when {
                !device.hasNotificationAccess() ->
                    Reply("Notification access is off. Turn it on in the Device Control screen first.", speak = false)
                !s.notificationReading ->
                    Reply("Reading notifications is disabled in Privacy settings.", speak = false)
                else -> {
                    val items = JarvisNotificationService.recent.value.take(5)
                    if (items.isEmpty()) Reply("No new notifications have arrived since J.A.R.V.I.S. started listening.")
                    else Reply(items.joinToString(". ") { "${it.app}: ${it.title} ${it.text}".trim() })
                }
            }
        }
    }

    /** Runs a command from a button (not shown in the chat). The result appears as a message toast. */
    fun quick(cmd: Command) {
        viewModelScope.launch {
            app.tasks.submit(describe(cmd), typeOf(cmd)) {
                val r = execute(cmd)
                toast(r.text)
                r.text.take(120)
            }
        }
    }

    fun requestCall(number: String) {
        val n = number.trim()
        if (n.isEmpty()) { toast("Enter a number first."); return }
        _confirm.value = ConfirmRequest(
            "Open dialer?",
            "J.A.R.V.I.S. will open the phone dialer with $n. You still have to press the call button yourself."
        ) { device.openDialer(n) }
    }

    fun requestSms(number: String, body: String) {
        val n = number.trim()
        if (n.isEmpty()) { toast("Enter a number first."); return }
        _confirm.value = ConfirmRequest(
            "Open messages?",
            "J.A.R.V.I.S. will open your messaging app with the text ready for $n. You still have to press send yourself."
        ) { device.openSmsComposer(n, body) }
    }

    fun runConfirmed() { val c = _confirm.value; _confirm.value = null; c?.action?.invoke() }
    fun dismissConfirm() { _confirm.value = null }

    fun shareText(text: String) { if (!device.shareText(text)) toast("Couldn't open the share sheet.") }
    fun openNotificationAccess() { device.openNotificationAccessSettings() }

    // ---------------- notes / reminders / tasks ----------------

    fun addNote(title: String, content: String) {
        if (title.isBlank() && content.isBlank()) return
        viewModelScope.launch { db.notes().insert(Note(title = title.ifBlank { content.take(30) }, content = content)) }
    }

    fun updateNote(n: Note) { viewModelScope.launch { db.notes().update(n) } }
    fun deleteNote(n: Note) { viewModelScope.launch { db.notes().delete(n) } }

    fun addReminder(text: String, minutes: Long) {
        if (text.isBlank()) { toast("Write what to be reminded about."); return }
        viewModelScope.launch {
            val at = System.currentTimeMillis() + minutes.coerceAtLeast(1) * 60_000L
            val id = db.reminders().insert(Reminder(text = text.trim(), triggerAt = at))
            ReminderWorker.schedule(getApplication(), id, at)
            toast("Reminder set.")
        }
    }

    fun deleteReminder(r: Reminder) {
        viewModelScope.launch {
            ReminderWorker.cancel(getApplication(), r.id)
            db.reminders().delete(r.id)
        }
    }

    fun setAlarm(hour: Int, minute: Int, label: String) {
        if (!device.setAlarm(hour, minute, label)) toast("No clock app could handle the alarm.")
    }

    fun cancelTask(id: Long) { app.tasks.cancel(id) }
    fun cancelAllTasks() { app.tasks.cancelAll() }
    fun clearTaskHistory() { viewModelScope.launch { app.tasks.clearHistory() } }

    // ---------------- settings setters ----------------

    fun setLanguage(v: String) = viewModelScope.launch { app.settings.setLanguage(v) }
    fun setModel(v: String) = viewModelScope.launch { app.settings.setModel(v.trim().ifEmpty { com.jarvis.assistant.data.DEFAULT_MODEL }) }
    fun setSpeechRate(v: Float) = viewModelScope.launch { app.settings.setSpeechRate(v) }
    fun setPitch(v: Float) = viewModelScope.launch { app.settings.setPitch(v) }
    fun setMaleVoice(v: Boolean) = viewModelScope.launch { app.settings.setMaleVoice(v) }
    fun setSpeakReplies(v: Boolean) = viewModelScope.launch { app.settings.setSpeakReplies(v) }
    fun setContinuous(v: Boolean) = viewModelScope.launch { app.settings.setContinuous(v) }
    fun setWakeWord(v: Boolean) = viewModelScope.launch { app.settings.setWakeWord(v) }
    fun setMuted(v: Boolean) = viewModelScope.launch { app.settings.setMuted(v) }
    fun setSaveHistory(v: Boolean) = viewModelScope.launch { app.settings.setSaveHistory(v) }
    fun setNotificationReading(v: Boolean) = viewModelScope.launch { app.settings.setNotificationReading(v) }

    fun testSpeech() {
        voice.speak(
            when (settings.value.language) {
                "hi" -> "नमस्ते, मैं जार्विस हूँ। आपकी सेवा में हाज़िर हूँ।"
                "bn" -> "নমস্কার, আমি জার্ভিস। আপনার সেবায় প্রস্তুত।"
                else -> "Hello, I am JARVIS. At your service."
            }
        )
    }

    override fun onCleared() {
        voice.shutdown()
        super.onCleared()
    }
}
