package com.jarvis.assistant.device

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.net.URLEncoder
import java.text.DateFormat
import java.util.Date

data class BatteryInfo(val percent: Int, val charging: Boolean)

/** Wraps official Android APIs. Nothing here bypasses permissions; calls/SMS only open the system app. */
class DeviceController(context: Context) {

    private val app = context.applicationContext
    private val cameraManager = app.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val audio = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private val _torchOn = MutableStateFlow(false)
    val torchOn: StateFlow<Boolean> = _torchOn.asStateFlow()

    private val torchCameraId: String? = runCatching {
        cameraManager.cameraIdList.firstOrNull { id ->
            val c = cameraManager.getCameraCharacteristics(id)
            c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        }
    }.getOrNull()

    init {
        runCatching {
            cameraManager.registerTorchCallback(object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                    if (cameraId == torchCameraId) _torchOn.value = enabled
                }
            }, Handler(Looper.getMainLooper()))
        }
    }

    val hasFlashlight: Boolean get() = torchCameraId != null

    /** Returns true on success. Needs no permission on Android 6+. */
    fun setFlashlight(on: Boolean): Boolean {
        val id = torchCameraId ?: return false
        return runCatching { cameraManager.setTorchMode(id, on); true }.getOrDefault(false)
    }

    fun toggleFlashlight(): Boolean = setFlashlight(!_torchOn.value)

    // ---------- launching things ----------

    private fun start(intent: Intent): Boolean = runCatching {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        app.startActivity(intent)
        true
    }.getOrDefault(false)

    private val aliases = mapOf(
        "youtube" to "com.google.android.youtube",
        "chrome" to "com.android.chrome",
        "camera" to "",
        "whatsapp" to "com.whatsapp",
        "maps" to "com.google.android.apps.maps",
        "gmail" to "com.google.android.gm",
        "play store" to "com.android.vending",
        "calculator" to "",
        "settings" to ""
    )

    /** Opens an installed app by (partial) name. Returns the app label opened, or null. */
    fun openApp(name: String): String? {
        val wanted = name.trim().lowercase()
        if (wanted.isEmpty()) return null
        val pm = app.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)

        val aliasPkg = aliases[wanted]?.takeIf { it.isNotEmpty() }
        val match = apps.firstOrNull { aliasPkg != null && it.activityInfo.packageName == aliasPkg }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().equals(wanted, true) }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().contains(wanted, true) }
            ?: return null

        val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return null
        return if (start(intent)) match.loadLabel(pm).toString() else null
    }

    fun openCamera(): Boolean = start(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))

    fun openSettings(): Boolean = start(Intent(Settings.ACTION_SETTINGS))

    fun openWebsite(url: String): Boolean {
        val fixed = if (url.startsWith("http://") || url.startsWith("https://")) url else "https://$url"
        return start(Intent(Intent.ACTION_VIEW, Uri.parse(fixed)))
    }

    fun webSearch(query: String): Boolean =
        openWebsite("https://www.google.com/search?q=" + URLEncoder.encode(query, "UTF-8"))

    fun shareText(text: String): Boolean {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        return start(Intent.createChooser(send, "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Opens the phone dialer with the number filled in. The user must press the call button. */
    fun openDialer(number: String): Boolean =
        start(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number))))

    /** Opens the messaging app with text prefilled. The user must press send. */
    fun openSmsComposer(number: String, body: String): Boolean =
        start(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number))).putExtra("sms_body", body))

    fun setAlarm(hour: Int, minute: Int, label: String): Boolean =
        start(
            Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, hour)
                .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                .putExtra(AlarmClock.EXTRA_MESSAGE, label)
                .putExtra(AlarmClock.EXTRA_SKIP_UI, false)
        )

    // ---------- volume ----------

    fun volumePercent(): Int {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        return audio.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / max
    }

    fun setVolumePercent(percent: Int): Boolean = runCatching {
        val max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, (percent.coerceIn(0, 100) * max / 100), AudioManager.FLAG_SHOW_UI)
        true
    }.getOrDefault(false)

    fun changeVolume(up: Boolean): Boolean = runCatching {
        audio.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
            AudioManager.FLAG_SHOW_UI
        )
        true
    }.getOrDefault(false)

    // ---------- status ----------

    fun battery(): BatteryInfo {
        val i = app.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else 0
        return BatteryInfo(pct, charging)
    }

    fun networkStatus(): String {
        val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return "OFFLINE"
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "WI-FI"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "MOBILE"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ETHERNET"
            else -> "ONLINE"
        }
    }

    fun isOnline(): Boolean = networkStatus() != "OFFLINE"

    fun timeText(): String = DateFormat.getTimeInstance(DateFormat.SHORT).format(Date())
    fun dateText(): String = DateFormat.getDateInstance(DateFormat.FULL).format(Date())

    // ---------- notification access ----------

    fun hasNotificationAccess(): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(app).contains(app.packageName)

    fun openNotificationAccessSettings(): Boolean =
        start(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))

    fun openAppDetailsSettings(): Boolean =
        start(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + app.packageName)))
}
