package com.jarvis.assistant.ai

import com.jarvis.assistant.data.SecureKeyStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** One turn of conversation sent to Gemini. role is "user" or "model". */
data class AiTurn(val role: String, val text: String)

sealed class AiResult {
    data class Success(val text: String) : AiResult()
    data class Failure(val message: String, val retryable: Boolean = false) : AiResult()
}

/**
 * Talks to the Gemini REST API. The API key is read from [SecureKeyStore] on every call,
 * sent in the x-goog-api-key header (never in the URL) and never logged.
 */
class GeminiClient(private val keyStore: SecureKeyStore) {

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val json = "application/json; charset=utf-8".toMediaType()

    suspend fun generate(
        model: String,
        history: List<AiTurn>,
        systemPrompt: String,
        maxAttempts: Int = 3
    ): AiResult {
        val key = keyStore.getApiKey()
            ?: return AiResult.Failure("No API key saved. Open Settings → Gemini API and add your key.")

        val body = JSONObject().apply {
            put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
            put("contents", JSONArray().apply {
                history.forEach { t ->
                    put(
                        JSONObject()
                            .put("role", if (t.role == "model") "model" else "user")
                            .put("parts", JSONArray().put(JSONObject().put("text", t.text)))
                    )
                }
            })
            put("generationConfig", JSONObject().put("temperature", 0.7).put("maxOutputTokens", 1024))
        }.toString()

        var last: AiResult.Failure = AiResult.Failure("Unknown error")
        for (attempt in 1..maxAttempts) {
            val result = callOnce(model, key, body)
            if (result is AiResult.Success) return result
            last = result as AiResult.Failure
            if (!last.retryable || attempt == maxAttempts) break
            delay(1000L * (1 shl (attempt - 1))) // 1s, 2s, 4s backoff
        }
        return last
    }

    /** Checks the saved key (or a candidate key) by listing models. Returns null on success, or an error message. */
    suspend fun testKey(candidate: String? = null): String? {
        val key = candidate?.trim()?.takeIf { it.isNotEmpty() } ?: keyStore.getApiKey()
            ?: return "No API key to test."
        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models?pageSize=1")
            .header("x-goog-api-key", key)
            .get()
            .build()
        return try {
            http.newCall(req).await().use { resp ->
                when {
                    resp.isSuccessful -> null
                    resp.code == 400 || resp.code == 401 || resp.code == 403 -> "The API key was rejected by Google. Check that it is correct."
                    resp.code == 429 -> "The key works but is rate limited right now. Try again soon."
                    else -> "Google returned error ${resp.code}."
                }
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: IOException) {
            "No internet connection or Google cannot be reached."
        }
    }

    private suspend fun callOnce(model: String, key: String, body: String): AiResult =
        withContext(Dispatchers.IO) {
            val req = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                .header("x-goog-api-key", key)
                .post(body.toRequestBody(json))
                .build()
            try {
                http.newCall(req).await().use { resp ->
                    val text = resp.body?.string().orEmpty()
                    if (resp.isSuccessful) parse(text) else failureFor(resp.code, text)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: IOException) {
                AiResult.Failure("Network problem. Check your internet connection.", retryable = true)
            } catch (e: Exception) {
                AiResult.Failure("Unexpected error while contacting Gemini.")
            }
        }

    private fun parse(raw: String): AiResult = try {
        val root = JSONObject(raw)
        val candidates = root.optJSONArray("candidates")
        if (candidates == null || candidates.length() == 0) {
            val reason = root.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            AiResult.Failure(if (reason.isNotEmpty()) "The request was blocked ($reason)." else "Gemini returned no answer.")
        } else {
            val parts = candidates.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            val sb = StringBuilder()
            if (parts != null) for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
            val out = sb.toString().trim()
            if (out.isEmpty()) AiResult.Failure("Gemini returned an empty answer.") else AiResult.Success(out)
        }
    } catch (e: Exception) {
        AiResult.Failure("Could not read Gemini's response.")
    }

    private fun failureFor(code: Int, raw: String): AiResult.Failure {
        val apiMsg = try {
            JSONObject(raw).optJSONObject("error")?.optString("message").orEmpty()
        } catch (e: Exception) { "" }
        return when (code) {
            400 -> AiResult.Failure(if (apiMsg.contains("API key", true)) "The API key is invalid." else "Bad request: ${apiMsg.take(160)}")
            401, 403 -> AiResult.Failure("The API key was rejected or lacks permission.")
            404 -> AiResult.Failure("Model not found. Pick another model in Settings → Gemini API.")
            429 -> AiResult.Failure("Rate limit reached. Wait a moment and try again.", retryable = true)
            in 500..599 -> AiResult.Failure("Gemini is temporarily unavailable.", retryable = true)
            else -> AiResult.Failure("Gemini error $code.")
        }
    }
}

private suspend fun Call.await(): Response = suspendCancellableCoroutine { cont ->
    enqueue(object : Callback {
        override fun onResponse(call: Call, response: Response) {
            cont.resume(response)
        }

        override fun onFailure(call: Call, e: IOException) {
            if (cont.isCancelled) return
            cont.resumeWithException(e)
        }
    })
    cont.invokeOnCancellation { runCatching { cancel() } }
}
