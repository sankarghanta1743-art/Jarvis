package com.jarvis.assistant.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.remember
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.assistant.AppViewModel
import com.jarvis.assistant.data.Note
import com.jarvis.assistant.ui.components.GlassPanel
import com.jarvis.assistant.ui.components.JarvisField
import com.jarvis.assistant.ui.components.NeonButton
import com.jarvis.assistant.ui.components.ScreenFrame
import com.jarvis.assistant.ui.components.SectionLabel
import com.jarvis.assistant.ui.theme.JColors
import java.text.DateFormat
import java.util.Date

@Composable
fun NotesScreen(vm: AppViewModel, onBack: () -> Unit) {
    val notes by vm.notes.collectAsStateWithLifecycle()
    var title by rememberSaveable { mutableStateOf("") }
    var body by rememberSaveable { mutableStateOf("") }
    var editing by remember { mutableStateOf<Note?>(null) }
    val fmt = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)

    ScreenFrame("Notes", onBack) {
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                SectionLabel("New note")
                JarvisField(title, { title = it }, "Title")
                JarvisField(body, { body = it }, "Note", Modifier.padding(top = 8.dp), singleLine = false, minLines = 3)
                NeonButton("Save note", { vm.addNote(title, body); title = ""; body = "" },
                    Modifier.padding(top = 8.dp), enabled = title.isNotBlank() || body.isNotBlank())
                SectionLabel("Saved notes (${notes.size})")
                if (notes.isEmpty()) Text("No notes yet. You can also say: \"Create a note: buy milk\".",
                    style = MaterialTheme.typography.bodySmall, color = JColors.TextDim)
            }
            items(notes, key = { it.id }) { n ->
                GlassPanel(Modifier.fillMaxWidth()) {
                    Text(n.title, style = MaterialTheme.typography.titleMedium, color = JColors.Cyan)
                    Text(n.content, style = MaterialTheme.typography.bodyMedium, color = JColors.Text, modifier = Modifier.padding(top = 4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(fmt.format(Date(n.createdAt)), style = MaterialTheme.typography.labelSmall, color = JColors.TextDim, modifier = Modifier.weight(1f))
                        IconButton(onClick = { editing = n }) { Icon(Icons.Filled.Edit, "Edit", tint = JColors.TextDim) }
                        IconButton(onClick = { vm.shareText("${n.title}\n${n.content}") }) { Icon(Icons.Filled.Share, "Share", tint = JColors.TextDim) }
                        IconButton(onClick = { vm.deleteNote(n) }) { Icon(Icons.Filled.Delete, "Delete", tint = JColors.Danger) }
                    }
                }
            }
        }
    }

    editing?.let { n ->
        var t by remember(n.id) { mutableStateOf(n.title) }
        var c by remember(n.id) { mutableStateOf(n.content) }
        AlertDialog(
            onDismissRequest = { editing = null },
            containerColor = androidx.compose.ui.graphics.Color(0xFF06141C),
            title = { Text("EDIT NOTE", color = JColors.Cyan, style = MaterialTheme.typography.titleMedium) },
            text = {
                Column {
                    JarvisField(t, { t = it }, "Title")
                    JarvisField(c, { c = it }, "Note", Modifier.padding(top = 8.dp), singleLine = false, minLines = 3)
                }
            },
            confirmButton = { TextButton({ vm.updateNote(n.copy(title = t, content = c)); editing = null }) { Text("SAVE", color = JColors.Cyan) } },
            dismissButton = { TextButton({ editing = null }) { Text("CANCEL", color = JColors.TextDim) } }
        )
    }
}

@Composable
fun RemindersScreen(vm: AppViewModel, onBack: () -> Unit) {
    val reminders by vm.reminders.collectAsStateWithLifecycle()
    var text by rememberSaveable { mutableStateOf("") }
    var amount by rememberSaveable { mutableStateOf("10") }
    var unit by rememberSaveable { mutableStateOf("min") }
    val fmt = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)

    ScreenFrame("Reminders", onBack) {
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                SectionLabel("New reminder")
                JarvisField(text, { text = it }, "Remind me to…")
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    JarvisField(amount, { amount = it.filter(Char::isDigit).take(4) }, "In", Modifier.weight(1f))
                    NeonButton("Min", { unit = "min" }, enabled = unit != "min")
                    NeonButton("Hr", { unit = "hr" }, enabled = unit != "hr")
                    NeonButton("Day", { unit = "day" }, enabled = unit != "day")
                }
                NeonButton("Set reminder", {
                    val n = (amount.toLongOrNull() ?: 1L).coerceAtLeast(1)
                    val minutes = when (unit) { "hr" -> n * 60; "day" -> n * 1440; else -> n }
                    vm.addReminder(text, minutes); text = ""
                }, Modifier.padding(top = 8.dp), enabled = text.isNotBlank())
                Text("Android may delay reminders by a minute or two when battery saver is on.",
                    style = MaterialTheme.typography.bodySmall, color = JColors.TextDim, modifier = Modifier.padding(top = 4.dp))
                SectionLabel("Your reminders (${reminders.size})")
            }
            items(reminders, key = { it.id }) { r ->
                GlassPanel(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(r.text, style = MaterialTheme.typography.bodyMedium, color = if (r.done) JColors.TextDim else JColors.Text)
                            Text("${fmt.format(Date(r.triggerAt))}${if (r.done) " · DONE" else ""}",
                                style = MaterialTheme.typography.labelSmall, color = if (r.done) JColors.Ok else JColors.Cyan)
                        }
                        IconButton(onClick = { vm.deleteReminder(r) }) { Icon(Icons.Filled.Delete, "Delete", tint = JColors.Danger) }
                    }
                }
            }
        }
    }
}

@Composable
fun HistoryScreen(vm: AppViewModel, onBack: () -> Unit, openChat: () -> Unit) {
    val convs by vm.conversations.collectAsStateWithLifecycle()
    val fmt = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
    var confirmAll by rememberSaveable { mutableStateOf(false) }

    ScreenFrame("History", onBack) {
        LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                SectionLabel("Conversations (${convs.size})")
                if (convs.isEmpty()) Text("Nothing here yet.", style = MaterialTheme.typography.bodySmall, color = JColors.TextDim)
                else NeonButton("Delete all", { confirmAll = true }, danger = true)
            }
            items(convs, key = { it.id }) { c ->
                GlassPanel(Modifier.fillMaxWidth(), onClick = { vm.openConversation(c.id); openChat() }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(c.title.ifBlank { "Conversation" }, style = MaterialTheme.typography.titleMedium, color = JColors.Cyan)
                            Text(fmt.format(Date(c.updatedAt)), style = MaterialTheme.typography.labelSmall, color = JColors.TextDim)
                        }
                        IconButton(onClick = { vm.deleteConversation(c.id) }) { Icon(Icons.Filled.Delete, "Delete", tint = JColors.Danger) }
                    }
                }
            }
        }
    }

    if (confirmAll) AlertDialog(
        onDismissRequest = { confirmAll = false },
        containerColor = androidx.compose.ui.graphics.Color(0xFF06141C),
        title = { Text("DELETE ALL HISTORY?", color = JColors.Danger, style = MaterialTheme.typography.titleMedium) },
        text = { Text("Every saved conversation will be erased from this phone.", color = JColors.Text) },
        confirmButton = { TextButton({ vm.clearAllHistory(); confirmAll = false }) { Text("DELETE", color = JColors.Danger) } },
        dismissButton = { TextButton({ confirmAll = false }) { Text("CANCEL", color = JColors.TextDim) } }
    )
}
