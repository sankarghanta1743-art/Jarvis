package com.jarvis.assistant.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.assistant.AppViewModel
import com.jarvis.assistant.data.SUGGESTED_MODELS
import com.jarvis.assistant.ui.components.GlassPanel
import com.jarvis.assistant.ui.components.JarvisField
import com.jarvis.assistant.ui.components.NeonButton
import com.jarvis.assistant.ui.components.ScreenFrame
import com.jarvis.assistant.ui.components.SectionLabel
import com.jarvis.assistant.ui.components.SwitchRow
import com.jarvis.assistant.ui.theme.JColors

@Composable
private fun LanguageChips(selected: String, onSelect: (String) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        listOf("en" to "English", "hi" to "हिन्दी", "bn" to "বাংলা").forEach { (code, label) ->
            FilterChip(
                selected = selected == code,
                onClick = { onSelect(code) },
                label = { Text(label) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = JColors.Cyan,
                    selectedLabelColor = JColors.Black
                )
            )
        }
    }
}

@Composable
fun ApiSettingsScreen(vm: AppViewModel, onBack: () -> Unit) {
    val hasKey by vm.hasKey.collectAsStateWithLifecycle()
    val masked by vm.maskedKey.collectAsStateWithLifecycle()
    val testMsg by vm.keyTestMsg.collectAsStateWithLifecycle()
    val testing by vm.keyTesting.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    var input by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    var model by remember(settings.model) { mutableStateOf(settings.model) }

    ScreenFrame("Gemini API", onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            GlassPanel(Modifier.fillMaxWidth()) {
                SectionLabel("Status")
                Text(
                    if (hasKey) "Key saved: $masked" else "No key saved yet.",
                    color = if (hasKey) JColors.Ok else JColors.Warn
                )
                Text(
                    "Your key is stored encrypted on this phone only and is sent only to Google's Gemini API.",
                    style = MaterialTheme.typography.bodySmall, color = JColors.TextDim,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
            GlassPanel(Modifier.fillMaxWidth()) {
                SectionLabel("Paste or update key")
                JarvisField(
                    value = input, onValueChange = { input = it }, label = "Gemini API key",
                    visual = if (show) VisualTransformation.None else PasswordVisualTransformation()
                )
                SwitchRow("Show key while typing", null, show) { show = it }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    NeonButton("Save", { vm.saveApiKey(input.trim()); input = "" }, Modifier.weight(1f), enabled = input.isNotBlank())
                    NeonButton("Test", { vm.testApiKey(input.trim().ifEmpty { null }) }, Modifier.weight(1f), enabled = !testing && (hasKey || input.isNotBlank()))
                }
                if (hasKey) {
                    NeonButton("Delete saved key", { vm.deleteApiKey() }, Modifier.fillMaxWidth().padding(top = 8.dp), danger = true)
                }
                if (testing) CircularProgressIndicator(Modifier.padding(top = 10.dp), color = JColors.Cyan)
                testMsg?.let {
                    Text(it, Modifier.padding(top = 8.dp), color = if (it.startsWith("✔")) JColors.Ok else JColors.Danger)
                }
            }
            GlassPanel(Modifier.fillMaxWidth()) {
                SectionLabel("Model")
                JarvisField(model, { model = it }, "Model name")
                Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SUGGESTED_MODELS.forEach { m ->
                        FilterChip(selected = model == m, onClick = { model = m }, label = { Text(m, style = MaterialTheme.typography.labelSmall) })
                    }
                }
                NeonButton("Apply model", { vm.setModel(model) }, Modifier.fillMaxWidth().padding(top = 8.dp))
            }
            GlassPanel(Modifier.fillMaxWidth()) {
                SectionLabel("Get a free key")
                Text(
                    "1. Open aistudio.google.com in Chrome.\n2. Sign in and tap “Get API key”.\n3. Copy the key, return here, paste it and tap Save, then Test.",
                    color = JColors.Text, style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

@Composable
fun VoiceSettingsScreen(vm: AppViewModel, onBack: () -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val note by vm.ttsNote.collectAsStateWithLifecycle()
    ScreenFrame("Voice setup", onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            GlassPanel(Modifier.fillMaxWidth()) {
                SectionLabel("Language")
                LanguageChips(s.language) { vm.setLanguage(it) }
                if (note.isNotBlank()) {
                    Text(note, Modifier.padding(top = 8.dp), color = JColors.Warn, style = MaterialTheme.typography.bodySmall)
                }
            }
            GlassPanel(Modifier.fillMaxWidth()) {
                SectionLabel("Speaking speed: %.1fx".format(s.speechRate))
                Slider(
                    value = s.speechRate, onValueChange = { vm.setSpeechRate(it) }, valueRange = 0.5f..2.0f,
                    colors = SliderDefaults.colors(thumbColor = JColors.Cyan, activeTrackColor = JColors.Cyan)
                )
                SectionLabel("Pitch: %.1f".format(s.pitch))
                Slider(
                    value = s.pitch, onValueChange = { vm.setPitch(it) }, valueRange = 0.5f..1.5f,
                    colors = SliderDefaults.colors(thumbColor = JColors.Cyan, activeTrackColor = JColors.Cyan)
                )
                NeonButton("Test voice", { vm.testSpeech() }, Modifier.fillMaxWidth())
            }
            GlassPanel(Modifier.fillMaxWidth()) {
                SwitchRow("Prefer male voice", "Used only if your phone's speech engine has one for this language.", s.preferMaleVoice) { vm.setMaleVoice(it) }
                SwitchRow("Speak replies aloud", null, s.speakReplies) { vm.setSpeakReplies(it) }
                SwitchRow("Mute voice", "Say “mute” or switch here.", s.muted) { vm.setMuted(it) }
                SwitchRow("Continuous conversation", "Listens again after each reply while the app is open.", s.continuousMode) { vm.setContinuous(it) }
                SwitchRow(
                    "Wake word “Hey JARVIS”",
                    "Works only while the app is open on screen. Android 10 does not allow reliable background wake words, so this is not always-on.",
                    s.wakeWordEnabled
                ) { vm.setWakeWord(it) }
            }
        }
    }
}

@Composable
fun AppSettingsScreen(vm: AppViewModel, onBack: () -> Unit) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val notifGranted by vm.notificationAccessGranted.collectAsStateWithLifecycle()
    ScreenFrame("App setup", onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            GlassPanel(Modifier.fillMaxWidth()) {
                SectionLabel("Privacy")
                SwitchRow("Save conversation history", "Stored only on this phone. Turn off to stop saving new chats.", s.saveHistory) { vm.setSaveHistory(it) }
                SwitchRow("Let JARVIS read notifications", "Needs Notification Access permission in Android settings.", s.notificationReading) { vm.setNotificationReading(it) }
                if (s.notificationReading) {
                    Text(
                        if (notifGranted) "Notification access: granted" else "Notification access: not granted",
                        color = if (notifGranted) JColors.Ok else JColors.Warn,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                    if (!notifGranted) NeonButton("Open Notification Access", { vm.openNotificationAccess() }, Modifier.fillMaxWidth().padding(top = 6.dp))
                }
            }
            GlassPanel(Modifier.fillMaxWidth()) {
                SectionLabel("Data")
                NeonButton("Clear all chat history", { vm.clearAllHistory() }, Modifier.fillMaxWidth(), danger = true)
                NeonButton("Clear task history", { vm.clearTaskHistory() }, Modifier.fillMaxWidth().padding(top = 8.dp), danger = true)
            }
            GlassPanel(Modifier.fillMaxWidth()) {
                SectionLabel("About")
                Text("J.A.R.V.I.S. 1.0 — Just A Rather Very Intelligent System", color = JColors.Text)
                Text(
                    "No analytics, no ads, no hidden data collection. Messages go only to Google's Gemini API using your own key. Calls and SMS always ask for your confirmation.",
                    color = JColors.TextDim, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
    }
}
