package com.jarvis.assistant.device

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class CapturedNotification(val app: String, val title: String, val text: String, val time: Long)

/**
 * Receives notifications ONLY if the user turns on Notification Access for J.A.R.V.I.S. in
 * Android settings AND enables "Allow reading notifications" inside the app.
 * Notifications are kept in memory only (last 25) and are never stored or sent anywhere.
 */
class JarvisNotificationService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!allowCapture) return
        if (sbn.packageName == packageName) return
        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        if (title.isEmpty() && text.isEmpty()) return
        val label = runCatching {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString()
        }.getOrDefault(sbn.packageName)
        val item = CapturedNotification(label, title, text, sbn.postTime)
        _recent.value = (listOf(item) + _recent.value).take(25)
    }

    override fun onListenerDisconnected() {
        _recent.value = emptyList()
    }

    companion object {
        @Volatile
        var allowCapture: Boolean = false
            set(value) {
                field = value
                if (!value) _recent.value = emptyList()
            }

        private val _recent = MutableStateFlow<List<CapturedNotification>>(emptyList())
        val recent: StateFlow<List<CapturedNotification>> = _recent.asStateFlow()
    }
}
