package com.jarvis.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

enum class ListenState { IDLE, LISTENING, PROCESSING }

sealed class VoiceEvent {
    data class Final(val text: String) : VoiceEvent()
    /** [silent] = just no speech heard (not worth showing as an error). */
    data class Error(val message: String, val silent: Boolean = false) : VoiceEvent()
}

/**
 * Speech-to-text (Android SpeechRecognizer) and text-to-speech (Android TextToSpeech).
 * MUST be created and used from the main thread.
 *
 * Note: SpeechRecognizer only works while the app is on screen. This app does NOT claim
 * background "Hey JARVIS" detection; the wake word works only while listening in the app.
 */
class VoiceManager(context: Context) {

    private val app = context.applicationContext

    // ---------------- speech to text ----------------

    private var recognizer: SpeechRecognizer? = null

    private val _listenState = MutableStateFlow(ListenState.IDLE)
    val listenState: StateFlow<ListenState> = _listenState.asStateFlow()

    private val _partial = MutableStateFlow("")
    val partial: StateFlow<String> = _partial.asStateFlow()

    /** Microphone loudness 0..1 for waveform animation. */
    private val _level = MutableStateFlow(0f)
    val level: StateFlow<Float> = _level.asStateFlow()

    private val _events = MutableSharedFlow<VoiceEvent>(extraBufferCapacity = 8)
    val events: SharedFlow<VoiceEvent> = _events.asSharedFlow()

    val recognitionAvailable: Boolean get() = SpeechRecognizer.isRecognitionAvailable(app)

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) { _listenState.value = ListenState.LISTENING }
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) { _level.value = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f) }
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { _listenState.value = ListenState.PROCESSING; _level.value = 0f }
        override fun onPartialResults(partialResults: Bundle?) {
            _partial.value = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
        }
        override fun onResults(results: Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().trim()
            reset()
            if (text.isNotEmpty()) _events.tryEmit(VoiceEvent.Final(text))
            else _events.tryEmit(VoiceEvent.Error("I didn't catch that.", silent = true))
        }
        override fun onError(error: Int) {
            reset()
            val (msg, silent) = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "I didn't hear anything." to true
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is needed." to false
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                    "Speech recognition needs internet for this language." to false
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Voice recognizer is busy. Try again." to false
                SpeechRecognizer.ERROR_AUDIO -> "Microphone error." to false
                else -> "Speech recognition error ($error)." to false
            }
            _events.tryEmit(VoiceEvent.Error(msg, silent))
        }
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun reset() {
        _listenState.value = ListenState.IDLE
        _level.value = 0f
        _partial.value = ""
    }

    /** Starts one listening session. [language] is "en", "hi" or "bn". */
    fun startListening(language: String) {
        if (!recognitionAvailable) {
            _events.tryEmit(VoiceEvent.Error("No speech recognition service found. Install or enable the Google app."))
            return
        }
        stopSpeaking()
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(app).also { it.setRecognitionListener(listener) }
        val tag = when (language) { "hi" -> "hi-IN"; "bn" -> "bn-IN"; else -> "en-IN" }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, tag)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, tag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, app.packageName)
        }
        _partial.value = ""
        _listenState.value = ListenState.PROCESSING // until onReadyForSpeech
        recognizer?.startListening(intent)
    }

    fun stopListening() {
        recognizer?.cancel()
        reset()
    }

    // ---------------- text to speech ----------------

    private var tts: TextToSpeech? = null
    private var ttsReady = false

    private val _speaking = MutableStateFlow(false)
    val speaking: StateFlow<Boolean> = _speaking.asStateFlow()

    private val _ttsNote = MutableStateFlow("")
    /** Non-empty when the phone has no voice data for the language being spoken. */
    val ttsNote: StateFlow<String> = _ttsNote.asStateFlow()

    var rate: Float = 1.0f
    var pitch: Float = 0.8f
    var preferMale: Boolean = true
    var muted: Boolean = false

    init {
        tts = TextToSpeech(app) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { _speaking.value = true }
                    override fun onDone(utteranceId: String?) { _speaking.value = false }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { _speaking.value = false }
                })
            } else {
                _ttsNote.value = "Text-to-speech engine could not start."
            }
        }
    }

    /** Speaks [text]. Hindi/Bengali script is detected automatically. */
    fun speak(text: String) {
        if (muted || !ttsReady || text.isBlank()) return
        val engine = tts ?: return
        val lang = detectLanguage(text)
        val locale = when (lang) { "hi" -> Locale("hi", "IN"); "bn" -> Locale("bn", "IN"); else -> Locale("en", "IN") }

        var res = engine.setLanguage(locale)
        if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
            if (lang == "bn") res = engine.setLanguage(Locale("bn", "BD"))
            if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                _ttsNote.value = "This phone has no ${langName(lang)} voice installed. " +
                    "Install it in Settings → System → Language → Text-to-speech."
                if (lang != "en") return
            }
        } else {
            _ttsNote.value = ""
        }

        pickVoice(engine, locale)
        engine.setSpeechRate(rate.coerceIn(0.5f, 2.0f))
        engine.setPitch(if (preferMale) pitch.coerceIn(0.5f, 1.2f) else 1.0f)
        // Split very long replies; TextToSpeech rejects text over getMaxSpeechInputLength.
        val max = TextToSpeech.getMaxSpeechInputLength() - 100
        var first = true
        text.chunked(max.coerceAtLeast(500)).forEach { part ->
            engine.speak(part, if (first) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "jarvis-${System.nanoTime()}")
            first = false
        }
    }

    fun stopSpeaking() {
        tts?.stop()
        _speaking.value = false
    }

    /**
     * Best effort: Android does not expose a "gender" flag, but many voices include
     * "male" in their name or feature list. Falls back to a lower pitch.
     */
    private fun pickVoice(engine: TextToSpeech, locale: Locale) {
        runCatching {
            val voices = engine.voices?.filter { it.locale.language == locale.language && !it.isNetworkConnectionRequired } .orEmpty()
            val chosen = if (preferMale) {
                voices.firstOrNull { v ->
                    val n = v.name.lowercase()
                    (n.contains("male") && !n.contains("female")) ||
                        v.features.any { it.equals("male", true) }
                }
            } else {
                voices.firstOrNull { it.name.lowercase().contains("female") }
            }
            if (chosen != null) engine.voice = chosen
        }
    }

    fun shutdown() {
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        tts = null
    }

    companion object {
        fun detectLanguage(text: String): String {
            var dev = 0
            var ben = 0
            text.forEach { c ->
                when (c.code) {
                    in 0x0900..0x097F -> dev++
                    in 0x0980..0x09FF -> ben++
                }
            }
            return when {
                dev > 2 && dev >= ben -> "hi"
                ben > 2 -> "bn"
                else -> "en"
            }
        }

        private fun langName(code: String) = when (code) { "hi" -> "Hindi"; "bn" -> "Bengali"; else -> "English" }
    }
}
