package com.jarvis.assistant.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [Conversation::class, ChatMessage::class, Note::class, Reminder::class, TaskRecord::class],
    version = 1,
    exportSchema = false
)
abstract class JarvisDatabase : RoomDatabase() {
    abstract fun conversations(): ConversationDao
    abstract fun messages(): MessageDao
    abstract fun notes(): NoteDao
    abstract fun reminders(): ReminderDao
    abstract fun tasks(): TaskDao

    companion object {
        fun create(context: Context): JarvisDatabase =
            Room.databaseBuilder(context.applicationContext, JarvisDatabase::class.java, "jarvis.db")
                .fallbackToDestructiveMigration()
                .build()
    }
}
