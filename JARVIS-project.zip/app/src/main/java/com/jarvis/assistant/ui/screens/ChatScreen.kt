package com.jarvis.assistant.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.assistant.AppViewModel
import com.jarvis.assistant.data.ChatMessage
import com.jarvis.assistant.ui.components.JarvisField
import com.jarvis.assistant.ui.components.ScreenFrame
import com.jarvis.assistant.ui.theme.JColors

@Composable
fun ChatScreen(vm: AppViewModel, onBack: () -> Unit, onMic: () -> Unit) {
    val messages by vm.messages.collectAsStateWithLifecycle()
    val thinking by vm.thinking.collectAsStateWithLifecycle()
    val error by vm.chatError.collectAsStateWithLifecycle()
    val partial by vm.partialText.collectAsStateWithLifecycle()
    var input by rememberSaveable { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size, thinking) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    ScreenFrame(
        title = "AI Chat",
        onBack = onBack,
        actions = {
            IconButton(onClick = { vm.newChat() }) { Icon(Icons.Filled.Add, "New chat", tint = JColors.Cyan) }
            IconButton(onClick = onMic) { Icon(Icons.Filled.Mic, "Speak", tint = JColors.Cyan) }
        }
    ) {
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (messages.isEmpty()) {
                item {
                    Text(
                        "Say hello, ask anything, or give a command such as \"open YouTube\", \"turn on flashlight\" or \"remind me in 10 minutes to drink water\".",
                        style = MaterialTheme.typography.bodyMedium, color = JColors.TextDim,
                        modifier = Modifier.padding(top = 24.dp)
                    )
                }
            }
            items(messages, key = { it.id }) { m -> Bubble(m, vm) }
            if (thinking) item {
                Text("J.A.R.V.I.S. is thinking…", style = MaterialTheme.typography.bodySmall, color = JColors.Cyan)
            }
            if (partial.isNotBlank()) item {
                Text("🎤 $partial", style = MaterialTheme.typography.bodySmall, color = JColors.TextDim)
            }
        }

        error?.let {
            Text(it, style = MaterialTheme.typography.bodySmall, color = JColors.Danger,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp))
        }

        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            JarvisField(input, { input = it }, "Message J.A.R.V.I.S.", Modifier.weight(1f))
            IconButton(onClick = { vm.submitInput(input); input = "" }) {
                Icon(Icons.AutoMirrored.Filled.Send, "Send", tint = JColors.Cyan)
            }
        }
    }
}

@Composable
private fun Bubble(m: ChatMessage, vm: AppViewModel) {
    val mine = m.role == "user"
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Column(horizontalAlignment = if (mine) Alignment.End else Alignment.Start) {
            Box(
                Modifier
                    .widthIn(max = 300.dp)
                    .background(if (mine) JColors.Blue.copy(alpha = 0.25f) else JColors.Glass, RoundedCornerShape(14.dp))
                    .border(1.dp, (if (mine) JColors.Blue else JColors.Cyan).copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                    .padding(12.dp)
            ) {
                Text(m.text, style = MaterialTheme.typography.bodyMedium, color = JColors.Text)
            }
            if (!mine) Row {
                IconButton(onClick = { vm.voice.speak(m.text) }) {
                    Icon(Icons.Filled.VolumeUp, "Read aloud", tint = JColors.TextDim)
                }
                IconButton(onClick = { vm.shareText(m.text) }) {
                    Icon(Icons.Filled.Share, "Share", tint = JColors.TextDim)
                }
            }
        }
    }
}
