package com.jarvis.assistant.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.assistant.AppViewModel
import com.jarvis.assistant.commands.Command
import com.jarvis.assistant.device.JarvisNotificationService
import com.jarvis.assistant.ui.components.GlassPanel
import com.jarvis.assistant.ui.components.JarvisField
import com.jarvis.assistant.ui.components.NeonButton
import com.jarvis.assistant.ui.components.ScreenFrame
import com.jarvis.assistant.ui.components.SectionLabel
import com.jarvis.assistant.ui.theme.JColors

@Composable
fun DeviceScreen(vm: AppViewModel, onBack: () -> Unit) {
    val status by vm.status.collectAsStateWithLifecycle()
    val torch by vm.torchOn.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val notifAccess by vm.notificationAccessGranted.collectAsStateWithLifecycle()
    val recent by JarvisNotificationService.recent.collectAsState()

    var appName by rememberSaveable { mutableStateOf("") }
    var url by rememberSaveable { mutableStateOf("") }
    var shareTxt by rememberSaveable { mutableStateOf("") }
    var phone by rememberSaveable { mutableStateOf("") }
    var sms by rememberSaveable { mutableStateOf("") }
    var hour by rememberSaveable { mutableStateOf("7") }
    var minute by rememberSaveable { mutableStateOf("0") }
    var alarmLabel by rememberSaveable { mutableStateOf("JARVIS alarm") }

    ScreenFrame("Device Control", onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(14.dp)) {
            GlassPanel(Modifier.fillMaxWidth()) {
                Text("BATTERY  ${status.battery}%${if (status.charging) "  (charging)" else ""}", style = MaterialTheme.typography.titleMedium, color = JColors.Cyan)
                Text("NETWORK  ${status.network}", style = MaterialTheme.typography.titleMedium, color = JColors.Cyan)
                Text("${status.date}  ${status.time}", style = MaterialTheme.typography.bodyMedium, color = JColors.TextDim)
            }

            SectionLabel("Quick actions")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NeonButton(if (torch) "Flash off" else "Flash on", { vm.quick(Command.Flashlight(!torch)) }, Modifier.weight(1f))
                NeonButton("Camera", { vm.quick(Command.OpenCamera) }, Modifier.weight(1f), Icons.Filled.CameraAlt)
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NeonButton("Vol -", { vm.quick(Command.Volume(false, null)) }, Modifier.weight(1f), Icons.Filled.VolumeDown)
                NeonButton("Vol +", { vm.quick(Command.Volume(true, null)) }, Modifier.weight(1f), Icons.Filled.VolumeUp)
                NeonButton("Settings", { vm.quick(Command.OpenSettings) }, Modifier.weight(1f), Icons.Filled.Settings)
            }

            SectionLabel("Open an app")
            JarvisField(appName, { appName = it }, "App name (e.g. YouTube, Chrome)")
            NeonButton("Open app", { vm.quick(Command.OpenApp(appName)) }, Modifier.padding(top = 8.dp), enabled = appName.isNotBlank())

            SectionLabel("Open a website")
            JarvisField(url, { url = it }, "Address (e.g. wikipedia.org)")
            NeonButton("Open website", { vm.quick(Command.OpenUrl(url.trim())) }, Modifier.padding(top = 8.dp), Icons.Filled.Language, enabled = url.isNotBlank())

            SectionLabel("Share text")
            JarvisField(shareTxt, { shareTxt = it }, "Text to share", singleLine = false, minLines = 2)
            NeonButton("Share", { vm.shareText(shareTxt) }, Modifier.padding(top = 8.dp), Icons.Filled.Share, enabled = shareTxt.isNotBlank())

            SectionLabel("Alarm (opens your clock app)")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                JarvisField(hour, { hour = it.filter(Char::isDigit).take(2) }, "Hour 0-23", Modifier.weight(1f))
                JarvisField(minute, { minute = it.filter(Char::isDigit).take(2) }, "Minute", Modifier.weight(1f))
            }
            JarvisField(alarmLabel, { alarmLabel = it }, "Label", Modifier.padding(top = 8.dp))
            NeonButton("Set alarm", {
                vm.setAlarm((hour.toIntOrNull() ?: 7).coerceIn(0, 23), (minute.toIntOrNull() ?: 0).coerceIn(0, 59), alarmLabel)
            }, Modifier.padding(top = 8.dp), Icons.Filled.Alarm)

            SectionLabel("Call or message (asks you first)")
            JarvisField(phone, { phone = it }, "Phone number")
            JarvisField(sms, { sms = it }, "Message text (for SMS)", Modifier.padding(top = 8.dp), singleLine = false, minLines = 2)
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NeonButton("Call", { vm.requestCall(phone) }, Modifier.weight(1f), Icons.Filled.Call)
                NeonButton("SMS", { vm.requestSms(phone, sms) }, Modifier.weight(1f), Icons.Filled.Sms)
            }
            Text("J.A.R.V.I.S. only opens the dialer or messaging app. You press call or send yourself.",
                style = MaterialTheme.typography.bodySmall, color = JColors.TextDim, modifier = Modifier.padding(top = 4.dp))

            SectionLabel("Notifications")
            GlassPanel(Modifier.fillMaxWidth()) {
                Text(
                    when {
                        !notifAccess -> "Notification access is OFF. It is optional. Turn it on only if you want JARVIS to read your notifications."
                        !settings.notificationReading -> "Android access is ON, but reading is disabled in App Settings → Privacy."
                        else -> "Reading is ON. Showing the last ${recent.size} notifications received since JARVIS started (kept in memory only)."
                    },
                    style = MaterialTheme.typography.bodySmall, color = JColors.TextDim
                )
                NeonButton(if (notifAccess) "Manage access" else "Grant access", { vm.openNotificationAccess() }, Modifier.padding(top = 8.dp))
                if (notifAccess && settings.notificationReading) {
                    recent.take(8).forEach {
                        Text("${it.app}: ${it.title} ${it.text}".trim(), style = MaterialTheme.typography.bodySmall,
                            color = JColors.Text, modifier = Modifier.padding(top = 6.dp))
                    }
                }
            }
        }
    }
}
