package com.jarvis.assistant.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.ui.theme.JColors
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

enum class CoreState { IDLE, LISTENING, THINKING, SPEAKING }

/**
 * The animated J.A.R.V.I.S. core: glowing 3D-style sphere, three rotating holographic rings,
 * a scanning radar sweep and a ring of voice-reactive bars.
 * [level] is microphone loudness (0..1) while listening.
 */
@Composable
fun JarvisCore(
    state: CoreState,
    level: Float,
    modifier: Modifier = Modifier,
    size: Dp = 280.dp
) {
    val speed by rememberUpdatedState(
        when (state) {
            CoreState.IDLE -> 1f
            CoreState.LISTENING -> 1.8f
            CoreState.THINKING -> 4.5f
            CoreState.SPEAKING -> 2.2f
        }
    )
    val time = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            androidx.compose.runtime.withFrameNanos { now ->
                if (last != 0L) time.floatValue += (now - last) / 1_000_000_000f * speed
                last = now
            }
        }
    }

    val smoothLevel by animateFloatAsState(
        targetValue = when (state) {
            CoreState.LISTENING -> level
            CoreState.SPEAKING -> 0.55f
            CoreState.THINKING -> 0.35f
            CoreState.IDLE -> 0.08f
        },
        animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "coreLevel"
    )

    val accent = when (state) {
        CoreState.THINKING -> Color(0xFF7C4DFF)
        CoreState.SPEAKING -> JColors.Blue
        else -> JColors.Cyan
    }

    Canvas(modifier = modifier.size(size)) {
        val t = time.floatValue
        val c = Offset(this.size.width / 2f, this.size.height / 2f)
        val r = this.size.minDimension / 2f
        val lv = smoothLevel

        // outer glow
        drawCircle(
            brush = Brush.radialGradient(
                listOf(accent.copy(alpha = 0.30f + 0.25f * lv), accent.copy(alpha = 0.08f), Color.Transparent),
                center = c, radius = r
            ),
            radius = r, center = c
        )

        // tick marks
        val ticks = 72
        for (i in 0 until ticks) {
            val a = i * 2 * PI / ticks
            val major = i % 6 == 0
            val r1 = r * 0.96f
            val r2 = r * (if (major) 0.90f else 0.93f)
            drawLine(
                accent.copy(alpha = if (major) 0.9f else 0.35f),
                Offset(c.x + (cos(a) * r1).toFloat(), c.y + (sin(a) * r1).toFloat()),
                Offset(c.x + (cos(a) * r2).toFloat(), c.y + (sin(a) * r2).toFloat()),
                strokeWidth = if (major) 2.5f else 1.2f
            )
        }

        // holographic rings
        ring(c, r * 0.86f, t * 24f, accent, 3.5f, floatArrayOf(r * 0.9f, r * 0.25f))
        ring(c, r * 0.76f, -t * 38f, JColors.Blue, 2.5f, floatArrayOf(r * 0.12f, r * 0.12f))
        ring(c, r * 0.64f, t * 60f, accent, 2f, floatArrayOf(r * 0.45f, r * 0.2f, r * 0.05f, r * 0.2f))

        // radar sweep
        rotate(degrees = (t * 90f) % 360f, pivot = c) {
            drawCircle(
                brush = Brush.sweepGradient(
                    0.0f to Color.Transparent,
                    0.80f to Color.Transparent,
                    1.0f to accent.copy(alpha = 0.55f),
                    center = c
                ),
                radius = r * 0.60f, center = c
            )
            drawLine(accent.copy(alpha = 0.9f), c, Offset(c.x + r * 0.60f, c.y), strokeWidth = 2f, cap = StrokeCap.Round)
        }
        drawCircle(accent.copy(alpha = 0.35f), r * 0.60f, c, style = Stroke(1.5f))
        drawCircle(accent.copy(alpha = 0.18f), r * 0.45f, c, style = Stroke(1f))

        // voice-reactive bars around the sphere
        val bars = 56
        val base = r * 0.30f
        for (i in 0 until bars) {
            val a = i * 2 * PI / bars
            val wobble = abs(sin(t * 3.2f + i * 0.7f)) * 0.6f + 0.4f
            val len = (r * 0.03f) + r * 0.17f * lv * wobble
            drawLine(
                brush = Brush.linearGradient(listOf(accent, JColors.Blue)),
                start = Offset(c.x + (cos(a) * base).toFloat(), c.y + (sin(a) * base).toFloat()),
                end = Offset(c.x + (cos(a) * (base + len)).toFloat(), c.y + (sin(a) * (base + len)).toFloat()),
                strokeWidth = 3f, cap = StrokeCap.Round
            )
        }

        // 3D-style sphere (offset highlight + dark rim)
        val coreR = r * 0.26f * (1f + 0.10f * lv)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.White, accent, JColors.DeepBlue, Color(0xFF00060D)),
                center = Offset(c.x - coreR * 0.35f, c.y - coreR * 0.35f),
                radius = coreR * 1.6f
            ),
            radius = coreR, center = c
        )
        drawCircle(accent.copy(alpha = 0.9f), coreR, c, style = Stroke(2f))
    }
}

private fun DrawScope.ring(c: Offset, radius: Float, deg: Float, color: Color, width: Float, dash: FloatArray) {
    rotate(degrees = deg, pivot = c) {
        drawArc(
            color = color.copy(alpha = 0.85f),
            startAngle = 0f, sweepAngle = 360f, useCenter = false,
            topLeft = Offset(c.x - radius, c.y - radius),
            size = Size(radius * 2, radius * 2),
            style = Stroke(width = width, cap = StrokeCap.Round, pathEffect = PathEffect.dashPathEffect(dash, 0f))
        )
    }
}

/** Horizontal audio waveform bars. When [active] is false they sit low and flat. */
@Composable
fun AudioWaveform(level: Float, active: Boolean, modifier: Modifier = Modifier) {
    val time = remember { mutableFloatStateOf(0f) }
    val lv by animateFloatAsState(if (active) level.coerceIn(0.05f, 1f) else 0.04f, label = "waveLevel")
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            androidx.compose.runtime.withFrameNanos { now ->
                if (last != 0L) time.floatValue += (now - last) / 1_000_000_000f
                last = now
            }
        }
    }
    Canvas(modifier = modifier.fillMaxWidth().height(48.dp)) {
        val n = 40
        val gap = size.width / n
        for (i in 0 until n) {
            val env = 1f - abs(i - n / 2f) / (n / 2f) * 0.6f
            val h = (size.height * 0.15f + size.height * 0.8f * lv * env * (abs(sin(time.floatValue * 5f + i * 0.5f)) * 0.7f + 0.3f))
                .coerceAtMost(size.height)
            val x = gap * i + gap / 2f
            drawLine(
                brush = Brush.verticalGradient(listOf(JColors.Cyan, JColors.Blue)),
                start = Offset(x, size.height / 2f - h / 2f),
                end = Offset(x, size.height / 2f + h / 2f),
                strokeWidth = gap * 0.5f, cap = StrokeCap.Round
            )
        }
    }
}
