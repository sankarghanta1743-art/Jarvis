package com.jarvis.assistant.commands

/** Everything the assistant can do locally, without asking Gemini. */
sealed class Command {
    object WakeOnly : Command()
    object StopSpeaking : Command()
    object Mute : Command()
    object Unmute : Command()
    data class OpenApp(val name: String) : Command()
    object OpenCamera : Command()
    object OpenSettings : Command()
    data class OpenUrl(val url: String) : Command()
    object Time : Command()
    object Date : Command()
    object Battery : Command()
    data class Flashlight(val on: Boolean) : Command()
    data class Search(val query: String) : Command()
    data class CreateNote(val text: String) : Command()
    data class SetReminder(val text: String, val delayMinutes: Long, val timeGiven: Boolean) : Command()
    data class Calculate(val expression: String) : Command()
    data class Volume(val up: Boolean?, val percent: Int?) : Command()
    data class Call(val number: String) : Command()
    object ReadNotifications : Command()
}

object CommandParser {

    private val wakePrefix = Regex("^(hey|hi|ok|okay|hello)?\\s*(jarvis|jarvish|jarvas|service)[,.!]?\\s*", RegexOption.IGNORE_CASE)

    /** Removes a leading "Hey JARVIS". Returns (hadWakeWord, remainingText). */
    fun stripWakeWord(input: String): Pair<Boolean, String> {
        val m = wakePrefix.find(input.trim())
        return if (m != null) true to input.trim().substring(m.range.last + 1).trim() else false to input.trim()
    }

    /** Returns a local command, or null if the sentence should go to Gemini. */
    fun parse(raw: String): Command? {
        val (woke, rest) = stripWakeWord(raw)
        val t = rest.lowercase().trim().trimEnd('.', '!', '?')
        if (t.isEmpty()) return if (woke) Command.WakeOnly else null

        // --- speech control ---
        if (t in setOf("stop", "stop speaking", "be quiet", "quiet", "shut up", "চুপ", "रुको", "चुप") ||
            t.startsWith("stop speaking") || t.startsWith("stop talking")
        ) return Command.StopSpeaking
        if (t == "mute" || t.startsWith("mute voice") || t.startsWith("mute yourself") || t == "म्यूट") return Command.Mute
        if (t == "unmute" || t.startsWith("unmute voice") || t.startsWith("speak again")) return Command.Unmute

        // --- flashlight (en / hi / bn) ---
        val torchWords = listOf("flashlight", "flash light", "torch", "टॉर्च", "टोर्च", "फ्लैशलाइट", "টর্চ", "ফ্ল্যাশলাইট")
        if (torchWords.any { t.contains(it) }) {
            val off = listOf("off", "disable", "बंद", "बन्द", "বন্ধ").any { t.contains(it) }
            return Command.Flashlight(!off)
        }

        // --- time / date / battery ---
        if (t.contains("what time") || t.contains("current time") || t == "time" || t.contains("टाइम") ||
            t.contains("समय क्या") || t.contains("कितने बजे") || t.contains("কয়টা বাজে") || t.contains("সময় কত")
        ) return Command.Time
        if (t.contains("what date") || t.contains("today's date") || t.contains("what day") || t.contains("आज की तारीख") ||
            t.contains("আজকের তারিখ")
        ) return Command.Date
        if (t.contains("battery") || t.contains("बैटरी") || t.contains("ব্যাটারি")) return Command.Battery

        // --- notifications ---
        if (t.contains("read my notifications") || t.contains("read notifications") || t.contains("my notifications"))
            return Command.ReadNotifications

        // --- phone controls ---
        if (t.contains("open camera") || t.contains("कैमरा खोल") || t.contains("ক্যামেরা খোল")) return Command.OpenCamera
        if (t == "open settings" || t.contains("सेटिंग खोल") || t.contains("সেটিংস খোল")) return Command.OpenSettings

        Regex("^(?:open|launch)\\s+(?:the\\s+)?(?:website\\s+|site\\s+)?((?:[a-z0-9-]+\\.)+[a-z]{2,}(?:/\\S*)?)$").find(t)
            ?.let { return Command.OpenUrl(it.groupValues[1]) }

        Regex("^(?:open|launch)\\s+(?:the\\s+)?(.+?)(?:\\s+app)?$").find(t)?.let {
            return Command.OpenApp(it.groupValues[1])
        }
        Regex("^(.+?)\\s*(?:खोलो|खोलें|खोल)$").find(t)?.let { return Command.OpenApp(it.groupValues[1].trim()) }
        Regex("^(.+?)\\s*(?:খোল|খুলো|খুলুন)$").find(t)?.let { return Command.OpenApp(it.groupValues[1].trim()) }

        // --- volume ---
        Regex("(?:set\\s+)?volume\\s+(?:to\\s+)?(\\d{1,3})").find(t)?.let {
            return Command.Volume(null, it.groupValues[1].toInt())
        }
        if (t.contains("volume up") || t.contains("increase volume") || t.contains("louder")) return Command.Volume(true, null)
        if (t.contains("volume down") || t.contains("decrease volume") || t.contains("lower volume") || t.contains("quieter"))
            return Command.Volume(false, null)

        // --- calling (always confirmed in the UI) ---
        Regex("^(?:call|dial|phone)\\s+([+0-9][0-9 \\-]{4,})$").find(t)?.let {
            return Command.Call(it.groupValues[1].replace(" ", "").replace("-", ""))
        }

        // --- reminders ---
        parseReminder(rest)?.let { return it }

        // --- notes ---
        Regex("^(?:create|make|add|write|take|save)\\s+(?:a\\s+)?note(?:\\s+(?:that|saying|about|to|:))?\\s*(.*)$", RegexOption.IGNORE_CASE)
            .find(rest.trim())?.let { return Command.CreateNote(it.groupValues[1].trim()) }
        Regex("^(?:note down|note that|note)\\s+(.+)$", RegexOption.IGNORE_CASE).find(rest.trim())
            ?.let { return Command.CreateNote(it.groupValues[1].trim()) }

        // --- calculator ---
        Regex("^(?:calculate|compute|what is|what's|whats|solve)\\s+(.+)$").find(t)?.let { m ->
            val expr = wordsToMath(m.groupValues[1])
            if (expr.any { it.isDigit() } && expr.all { it.isDigit() || it in "+-*/^%(). " }) return Command.Calculate(expr)
        }
        Regex("^(?:calculate|compute|solve)\\s*$").find(t)?.let { return Command.Calculate("") }

        // --- web search ---
        Regex("^(?:search|google|look up|find)\\s+(?:the\\s+)?(?:internet|web|google|online)?\\s*(?:for\\s+)?(.*)$").find(t)?.let {
            return Command.Search(it.groupValues[1].trim())
        }

        return null
    }

    private fun parseReminder(raw: String): Command.SetReminder? {
        val s = raw.trim().trimEnd('.', '!', '?')
        val lower = s.lowercase()
        if (!lower.contains("remind") && !lower.contains("reminder")) return null

        val unitRx = "(second|sec|minute|min|hour|hr|day)s?"
        // "remind me in 10 minutes to call mom"
        Regex("remind(?:er)?(?:\\s+me)?\\s+in\\s+(\\d+)\\s+$unitRx\\s*(?:to|that|about)?\\s*(.*)", RegexOption.IGNORE_CASE).find(s)?.let {
            return Command.SetReminder(it.groupValues[3].ifBlank { "Reminder" }, toMinutes(it.groupValues[1], it.groupValues[2]), true)
        }
        // "remind me to call mom in 10 minutes"
        Regex("remind(?:er)?(?:\\s+me)?\\s+(?:to|that|about)\\s+(.+?)\\s+in\\s+(\\d+)\\s+$unitRx$", RegexOption.IGNORE_CASE).find(s)?.let {
            return Command.SetReminder(it.groupValues[1], toMinutes(it.groupValues[2], it.groupValues[3]), true)
        }
        // "set a reminder in 5 minutes"  /  "set a reminder for 5 minutes to drink water"
        Regex("reminder\\s+(?:in|for)\\s+(\\d+)\\s+$unitRx\\s*(?:to|that|about)?\\s*(.*)", RegexOption.IGNORE_CASE).find(s)?.let {
            return Command.SetReminder(it.groupValues[3].ifBlank { "Reminder" }, toMinutes(it.groupValues[1], it.groupValues[2]), true)
        }
        // no time given
        Regex("remind(?:er)?(?:\\s+me)?\\s+(?:to|that|about)\\s+(.+)", RegexOption.IGNORE_CASE).find(s)?.let {
            return Command.SetReminder(it.groupValues[1], 30, false)
        }
        return Command.SetReminder("Reminder", 30, false)
    }

    private fun toMinutes(n: String, unit: String): Long {
        val v = n.toLongOrNull() ?: 1
        return when (unit.lowercase().take(3)) {
            "sec" -> maxOf(1, v / 60)
            "min" -> v
            "hou", "hr" -> v * 60
            "day" -> v * 1440
            else -> v
        }
    }

    private fun wordsToMath(s: String): String =
        s.lowercase()
            .replace("multiplied by", "*").replace("times", "*").replace(" into ", " * ").replace(" x ", " * ")
            .replace("divided by", "/").replace(" over ", " / ")
            .replace("to the power of", "^").replace("power", "^")
            .replace("plus", "+").replace("minus", "-")
            .replace("modulo", "%").replace("mod", "%")
            .replace(",", "")
            .trim()
}
