package com.jarvis.assistant.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FlashlightOff
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.StickyNote2
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.assistant.AppViewModel
import com.jarvis.assistant.commands.Command
import com.jarvis.assistant.ui.components.AudioWaveform
import com.jarvis.assistant.ui.components.CoreState
import com.jarvis.assistant.ui.components.GlassPanel
import com.jarvis.assistant.ui.components.JarvisCore
import com.jarvis.assistant.ui.components.JarvisField
import com.jarvis.assistant.ui.components.NeonButton
import com.jarvis.assistant.ui.components.SectionLabel
import com.jarvis.assistant.ui.components.StatusChip
import com.jarvis.assistant.ui.theme.JColors
import com.jarvis.assistant.voice.ListenState

@Composable
fun coreStateOf(vm: AppViewModel): CoreState {
    val listen by vm.listenState.collectAsStateWithLifecycle()
    val speaking by vm.speaking.collectAsStateWithLifecycle()
    val thinking by vm.thinking.collectAsStateWithLifecycle()
    return when {
        speaking -> CoreState.SPEAKING
        thinking -> CoreState.THINKING
        listen == ListenState.LISTENING -> CoreState.LISTENING
        listen == ListenState.PROCESSING -> CoreState.THINKING
        else -> CoreState.IDLE
    }
}

fun statusText(core: CoreState, session: Boolean): String = when (core) {
    CoreState.LISTENING -> "LISTENING..."
    CoreState.THINKING -> "PROCESSING..."
    CoreState.SPEAKING -> "SPEAKING"
    CoreState.IDLE -> if (session) "SESSION ACTIVE" else "STANDBY"
}

@Composable
fun DashboardScreen(vm: AppViewModel, nav: (String) -> Unit, onMic: () -> Unit) {
    val status by vm.status.collectAsStateWithLifecycle()
    val core = coreStateOf(vm)
    val level by vm.micLevel.collectAsStateWithLifecycle()
    val partial by vm.partialText.collectAsStateWithLifecycle()
    val session by vm.sessionActive.collectAsStateWithLifecycle()
    val active by vm.activeTasks.collectAsStateWithLifecycle()
    val hasKey by vm.hasKey.collectAsStateWithLifecycle()
    val torch by vm.torchOn.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    var input by rememberSaveable { mutableStateOf("") }

    Column(
        Modifier
            .fillMaxSize()
            .background(JColors.Black)
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // header
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("J.A.R.V.I.S.", style = MaterialTheme.typography.headlineMedium, color = JColors.Cyan)
                Text("JUST A RATHER VERY INTELLIGENT SYSTEM", style = MaterialTheme.typography.labelSmall, color = JColors.TextDim)
            }
            IconButton(onClick = { nav("settings") }) {
                Icon(Icons.Filled.Settings, contentDescription = "Settings", tint = JColors.Cyan)
            }
        }

        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatusChip("Battery", "${status.battery}%${if (status.charging) " ⚡" else ""}",
                if (status.battery <= 20 && !status.charging) JColors.Danger else JColors.Cyan, Modifier.weight(1f))
            StatusChip("Network", status.network,
                if (status.network == "OFFLINE") JColors.Danger else JColors.Cyan, Modifier.weight(1f))
            StatusChip("Time", status.time, modifier = Modifier.weight(1.3f))
        }
        Text(status.date.uppercase(), style = MaterialTheme.typography.labelSmall, color = JColors.TextDim,
            modifier = Modifier.padding(top = 4.dp))

        // core
        Spacer(Modifier.height(6.dp))
        Box(onClick = onMic) { JarvisCore(core, level) }
        Text(statusText(core, session), style = MaterialTheme.typography.titleMedium, color = JColors.Cyan)
        Text(
            if (partial.isNotBlank()) "“$partial”"
            else "VOICE: ${if (settings.muted) "MUTED" else "ON"}  ·  LANG: ${settings.language.uppercase()}",
            style = MaterialTheme.typography.bodySmall, color = JColors.TextDim, textAlign = TextAlign.Center,
            modifier = Modifier.padding(vertical = 4.dp)
        )
        AudioWaveform(level, active = core == CoreState.LISTENING || core == CoreState.SPEAKING)

        // mic controls
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            NeonButton("Listen", onClick = onMic, icon = Icons.Filled.Mic)
            NeonButton("Stop", onClick = { vm.stopVoice(); vm.interruptSpeech() }, icon = Icons.Filled.Stop, danger = true)
        }

        // text input
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            JarvisField(input, { input = it }, "Type a message or command", Modifier.weight(1f))
            IconButton(onClick = { vm.submitInput(input); input = ""; nav("chat") }) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = JColors.Cyan)
            }
        }

        if (!hasKey) {
            Spacer(Modifier.height(8.dp))
            GlassPanel(Modifier.fillMaxWidth(), onClick = { nav("api") }) {
                Text("No Gemini API key yet.", style = MaterialTheme.typography.titleMedium, color = JColors.Warn)
                Text("Tap here to add it. Voice commands like \"open YouTube\" work without a key, AI answers need one.",
                    style = MaterialTheme.typography.bodySmall, color = JColors.TextDim)
            }
        }

        // active tasks
        SectionLabel("Active tasks", Modifier.fillMaxWidth())
        GlassPanel(Modifier.fillMaxWidth()) {
            if (active.isEmpty()) {
                Text("No tasks running.", style = MaterialTheme.typography.bodySmall, color = JColors.TextDim)
            } else active.forEach { t ->
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(t.title, style = MaterialTheme.typography.bodyMedium, color = JColors.Text)
                        Text(t.status, style = MaterialTheme.typography.labelSmall,
                            color = if (t.status == "RUNNING") JColors.Cyan else JColors.TextDim)
                    }
                    IconButton(onClick = { vm.cancelTask(t.id) }) {
                        Icon(Icons.Filled.Close, contentDescription = "Cancel task", tint = JColors.Danger)
                    }
                }
            }
        }

        // quick controls
        SectionLabel("Quick controls", Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NeonButton(if (torch) "Light off" else "Light on", { vm.quick(Command.Flashlight(!torch)) },
                Modifier.weight(1f), if (torch) Icons.Filled.FlashlightOff else Icons.Filled.FlashlightOn)
            NeonButton("Camera", { vm.quick(Command.OpenCamera) }, Modifier.weight(1f), Icons.Filled.CameraAlt)
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NeonButton("Time", { vm.quick(Command.Time) }, Modifier.weight(1f), Icons.Filled.Schedule)
            NeonButton("Battery", { vm.quick(Command.Battery) }, Modifier.weight(1f), Icons.Filled.PhoneAndroid)
        }

        // navigation
        SectionLabel("Modules", Modifier.fillMaxWidth())
        val modules: List<Triple<String, String, ImageVector>> = listOf(
            Triple("AI Chat", "chat", Icons.Filled.Chat),
            Triple("Voice", "voice", Icons.Filled.RecordVoiceOver),
            Triple("Tasks", "tasks", Icons.Filled.Memory),
            Triple("Device", "device", Icons.Filled.PhoneAndroid),
            Triple("Notes", "notes", Icons.Filled.StickyNote2),
            Triple("Reminders", "reminders", Icons.Filled.Alarm),
            Triple("History", "history", Icons.Filled.History),
            Triple("Gemini API", "api", Icons.Filled.Key),
            Triple("Voice setup", "voicesettings", Icons.Filled.GraphicEq),
            Triple("App setup", "settings", Icons.Filled.Tune)
        )
        modules.chunked(2).forEach { pair ->
            Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                pair.forEach { (label, route, icon) ->
                    NeonButton(label, { nav(route) }, Modifier.weight(1f), icon)
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

/** Small clickable wrapper so the animated core can act as a mic button. */
@Composable
private fun Box(onClick: () -> Unit, content: @Composable () -> Unit) {
    androidx.compose.foundation.layout.Box(
        Modifier.clip(CircleShape).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { content() }
}
