package com.jarvis.assistant.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.ButtonDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.jarvis.assistant.ui.theme.JColors

private val panelShape = RoundedCornerShape(16.dp)

@Composable
fun GlassPanel(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val base = modifier
        .clip(panelShape)
        .background(Brush.verticalGradient(listOf(JColors.GlassStrong, JColors.Glass)))
        .border(BorderStroke(1.dp, Brush.linearGradient(listOf(JColors.Cyan.copy(alpha = 0.7f), JColors.Blue.copy(alpha = 0.2f)))), panelShape)
    Column(
        modifier = (if (onClick != null) base.clickable { onClick() } else base).padding(14.dp),
        content = content
    )
}

@Composable
fun NeonButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    danger: Boolean = false
) {
    val color = if (danger) JColors.Danger else JColors.Cyan
    OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.2.dp, color.copy(alpha = if (enabled) 0.9f else 0.3f)),
        colors = ButtonDefaults.outlinedButtonColors(containerColor = color.copy(alpha = 0.08f), contentColor = color),
        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 10.dp)
    ) {
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.height(18.dp))
            Spacer(Modifier.width(8.dp))
        }
        Text(text.uppercase(), style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text.uppercase(),
        style = MaterialTheme.typography.labelMedium,
        color = JColors.Cyan,
        modifier = modifier.padding(top = 14.dp, bottom = 6.dp)
    )
}

@Composable
fun SwitchRow(title: String, description: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = JColors.Text)
            if (description != null) Text(description, style = MaterialTheme.typography.bodySmall, color = JColors.TextDim)
        }
        Spacer(Modifier.width(10.dp))
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = JColors.Black, checkedTrackColor = JColors.Cyan,
                uncheckedThumbColor = JColors.TextDim, uncheckedTrackColor = JColors.Black,
                uncheckedBorderColor = JColors.TextDim
            )
        )
    }
}

@Composable
fun jarvisFieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = JColors.Cyan,
    unfocusedBorderColor = JColors.Cyan.copy(alpha = 0.4f),
    focusedTextColor = JColors.Text,
    unfocusedTextColor = JColors.Text,
    cursorColor = JColors.Cyan,
    focusedLabelColor = JColors.Cyan,
    unfocusedLabelColor = JColors.TextDim,
    focusedContainerColor = JColors.Glass,
    unfocusedContainerColor = JColors.Glass
)

@Composable
fun JarvisField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    singleLine: Boolean = true,
    minLines: Int = 1,
    visual: VisualTransformation = VisualTransformation.None
) {
    OutlinedTextField(
        value = value, onValueChange = onValueChange,
        label = { Text(label) },
        modifier = modifier.fillMaxWidth(),
        singleLine = singleLine, minLines = minLines,
        visualTransformation = visual,
        shape = RoundedCornerShape(12.dp),
        colors = jarvisFieldColors()
    )
}

@Composable
fun StatusChip(label: String, value: String, valueColor: Color = JColors.Cyan, modifier: Modifier = Modifier) {
    Column(
        modifier
            .clip(RoundedCornerShape(10.dp))
            .background(JColors.Glass)
            .border(1.dp, JColors.Cyan.copy(alpha = 0.35f), RoundedCornerShape(10.dp))
            .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(label.uppercase(), style = MaterialTheme.typography.labelSmall, color = JColors.TextDim)
        Text(value, style = MaterialTheme.typography.titleMedium, color = valueColor)
    }
}

/** Standard frame for every sub-screen: black background, back arrow, glowing title. */
@Composable
fun ScreenFrame(
    title: String,
    onBack: () -> Unit,
    actions: @Composable () -> Unit = {},
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        Modifier
            .fillMaxSize()
            .background(JColors.Black)
            .statusBarsPadding()
    ) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = JColors.Cyan)
            }
            Text(title.uppercase(), style = MaterialTheme.typography.titleLarge, color = JColors.Cyan, modifier = Modifier.weight(1f))
            actions()
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(Brush.horizontalGradient(listOf(JColors.Cyan, JColors.Blue, Color.Transparent))))
        Column(Modifier.weight(1f).fillMaxWidth(), content = content)
    }
}
