# J.A.R.V.I.S. – build the APK from your phone (no PC)

Your phone can't compile this project itself, so GitHub's free cloud computer does it.

1. Make a free account at github.com and create a NEW EMPTY repository named `jarvis` (Public or Private).
2. Install **Termux** from F-Droid (f-droid.org). Open it and run:
   pkg install -y git unzip
   termux-setup-storage
   cd ~ && unzip ~/storage/downloads/JARVIS-project.zip -d jarvis && cd jarvis
   git init -b main && git add . && git commit -m "JARVIS"
   git remote add origin https://github.com/YOURNAME/jarvis.git
   git push -u origin main
   (GitHub asks for a username and a "personal access token" as password:
   github.com > Settings > Developer settings > Personal access tokens > give it "repo" + "workflow" scope.)
3. In the repo open the **Actions** tab. "Build JARVIS APK" runs by itself (about 5-8 min). Open the finished run and download **JARVIS-debug-apk**.
4. Unzip it, tap `app-debug.apk`, allow "Install unknown apps" for your browser/files app, install.
5. Open JARVIS > Gemini API > paste your key from aistudio.google.com > Save > Test.

If the Actions run shows a red X, copy the error text to me and I'll fix it.

Release APK: the same workflow also makes an unsigned release APK. A phone only installs a *signed* one, so use the debug APK for yourself.
